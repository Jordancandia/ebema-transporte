// ============================================================================
// GESTION TRONCALES / ABASTECIMIENTO  —  AJUSTES 3.0
// ----------------------------------------------------------------------------
// Planificacion de cargas de productos a las sucursales desde CD (o cualquier
// origen). Submenus: Proveedores, Calendario Sucursales, vistas de datos SAP
// (Quiebres, Retiros, Ventas 1003, Traslados, Stock 4000, Traslados 4000) y el
// dashboard Plan de Carga.
//
// Persistencia: Supabase (abast_proveedores, abast_proveedor_direcciones,
// abast_calendario, abast_retiro_estado) + vistas v_trc_* sobre trc_live (JSONB).
// ============================================================================

import { supabase } from './supabase-client.js?v=202609300011';
import { getDatabase } from './data.js?v=202609300011';
import { showAlert, escapeHtml } from './utils.js';

// ── Configuracion de calendarios por centro origen ──────────────────────────
// (AJUSTE 3.0) Se eliminan los sobre-cupos del sábado.
const CALENDARIOS = {
  '1003': {
    nombre: 'CD Quilicura',
    bloques: ['07:30-11:30', '11:00-15:00', '15:30-19:30'],
    dias: [
      { n: 1, lbl: 'Lunes',     corto: 'LUN' },
      { n: 2, lbl: 'Martes',    corto: 'MAR' },
      { n: 3, lbl: 'Miércoles', corto: 'MIE' },
      { n: 4, lbl: 'Jueves',    corto: 'JUE' },
      { n: 5, lbl: 'Viernes',   corto: 'VIE' },
    ],
    destinos: ['1020','1040','1050','1060','1070','1080','1090','1100','1160','1005'],
  },
  '1081': {
    nombre: 'CD Concepción',
    bloques: ['08:00-11:00', '11:00-15:00'],
    dias: [
      { n: 1, lbl: 'Lunes',     corto: 'LUN' },
      { n: 2, lbl: 'Martes',    corto: 'MAR' },
      { n: 3, lbl: 'Miércoles', corto: 'MIE' },
      { n: 4, lbl: 'Jueves',    corto: 'JUE' },
      { n: 5, lbl: 'Viernes',   corto: 'VIE' },
    ],
    destinos: ['1100','1090','1160','1070','1060','1005','1003'],
  },
};

// ── Estado del modulo ───────────────────────────────────────────────────────
let currentSub = 'proveedores';
let proveedores = [];
let selectedProveedorId = null;
let calOrigen = '1003';
let calMatrix = {};
let rootEl = null;

// ── Utilidades ──────────────────────────────────────────────────────────────
async function getUserEmail() {
  try {
    const { data } = await supabase.auth.getUser();
    return data?.user?.email || null;
  } catch { return null; }
}

export function setAbastSubTab(sub) {
  if (sub) currentSub = sub;
}

// ============================================================================
// HELPERS PARA VISTAS DE DATOS
// ============================================================================
function parseDateSAP(s) {
  if (!s) return null;
  const m = String(s).match(/^(\d{2})\.(\d{2})\.(\d{4})$/);
  if (!m) return null;
  return new Date(+m[3], +m[2] - 1, +m[1]);
}

function hoy00() { const d = new Date(); d.setHours(0,0,0,0); return d; }

function alertaFecha(fechaStr, diasUmbral = 5) {
  const d = parseDateSAP(fechaStr);
  if (!d) return { txt: '', cls: '' };
  const hoy = hoy00();
  const diff = Math.floor((d - hoy) / 86400000);
  if (diff < 0) return { txt: 'PEDIDO ATRASADO', cls: 'text-error font-bold' };
  if (diff <= diasUmbral) return { txt: 'PRONTO A VENCER', cls: 'text-[#e65100] font-bold' };
  return { txt: '', cls: '' };
}

// Número SAP → float (puntos = miles, coma = decimal)
function parseNum(v) {
  return parseFloat(String(v ?? '').replace(/\./g, '').replace(',', '.')) || 0;
}

// MAX(peso_bruto, tamano_dimens) en número
function maxPesoDim(peso, dim) {
  return Math.max(parseNum(peso), parseNum(dim));
}

// Tonelaje = pesoMax * cantidad / 1000
function calcTon(pesoMax, cantidad) {
  return pesoMax * parseNum(cantidad) / 1000;
}

function fmtNum(n, dec = 2) {
  if (n == null || isNaN(n)) return '';
  return n.toLocaleString('es-CL', { minimumFractionDigits: dec, maximumFractionDigits: dec });
}

function lookupRuta(rutaId) {
  if (!rutaId) return { comuna: '', region: '' };
  const db = getDatabase();
  const r = (db.routes || []).find(x => x.codigo === String(rutaId).trim());
  return r ? { comuna: r.comuna || '', region: r.region || '' } : { comuna: '', region: '' };
}

function horaChile(ts) {
  if (!ts) return '';
  try {
    const d = new Date(ts);
    return d.toLocaleString('es-CL', { timeZone: 'America/Santiago', day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });
  } catch { return String(ts).slice(0, 16).replace('T', ' '); }
}

const CENTROS_QUIEBRES = ['1005','1020','1040','1050','1060','1070','1080','1090','1100','1160'];

// Orden de clase ABC solicitado: AA, AB, AC, BA, BB, BC, CA, CB, CC
const ABC_ORDEN = { AA:0, AB:1, AC:2, BA:3, BB:4, BC:5, CA:6, CB:7, CC:8 };
function abcRank(abc) {
  const k = String(abc ?? '').trim().toUpperCase();
  return ABC_ORDEN[k] != null ? ABC_ORDEN[k] : 99;
}

// Normaliza texto: quita acentos/ñ y pasa a MAYÚSCULAS.
function normTxt(s) {
  return String(s ?? '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toUpperCase().trim();
}

// Comunas que están "en el camino" hacia cada centro destino: un pedido de venta
// cuya comuna (según maestro de rutas) esté en la lista puede dejarse en ruta.
// Claves normalizadas (sin acentos/ñ) para hacer match por nombre de centro.
const COMUNAS_EN_CAMINO = {
  'ANTOFAGASTA':  new Set(['CHANARAL','TALTAL','CALDERA','COPIAPO']),
  'COQUIMBO':     new Set(['LOS VILOS','PICHIDANGUI','LA LIGUA']),
  'RANCAGUA':     new Set(['BUIN','PAINE','MOSTAZAL','GRANEROS']),
  'TALCA':        new Set(['CURICO','SAN RAFAEL']),
  'CHILLAN':      new Set(['SAN CARLOS','SAN GREGORIO','LINARES','PARRAL']),
  'TEMUCO':       new Set(['LAUTARO','VICTORIA','COLLIPULLI']),
  'PUERTO MONTT': new Set(['RIO BUENO','PUERTO VARAS','FRUTILLAR','LLANQUIHUE','OSORNO','PURRANQUE','SAN PABLO']),
  'CONCEPCION':   new Set(['PENCO','TALCAHUANO','HUALPEN']),
};

// Devuelve el Set de comunas "en el camino" para el centro dado (por nombre).
function comunasEnCamino(centroId) {
  const nombre = normTxt(getNombreCentro(centroId));
  for (const key of Object.keys(COMUNAS_EN_CAMINO)) {
    if (nombre.indexOf(key) !== -1) return COMUNAS_EN_CAMINO[key];
  }
  return new Set();
}

// Clasificación de quiebre por días de stock (AJUSTE 3.0)
function tipoQuiebre(sd) {
  if (sd <= 3)  return { txt: 'MATERIAL QUEBRADO URGENTE', cls: 'text-white bg-red-600', dot: 'bg-red-600' };
  if (sd <= 5)  return { txt: 'STOCK CRÍTICO URGENTE',     cls: 'text-white bg-[#e65100]', dot: 'bg-[#e65100]' };
  return          { txt: 'STOCK EN REVISIÓN',              cls: 'text-black bg-[#f9a825]', dot: 'bg-[#f9a825]' };
}

// ── Estado de coordinación de retiros (persistente) ─────────────────────────
async function loadEstadosRetiro() {
  const { data, error } = await supabase.from('abast_retiro_estado').select('doc_compr, estado, tipo_retiro, entrega_entrante, tipo_local_rm, fab_direccion, fab_comuna, fab_contacto, fab_telefono');
  const m = {};
  if (!error) (data || []).forEach(r => { m[String(r.doc_compr)] = { estado: r.estado, tipo_retiro: r.tipo_retiro, entrega_entrante: r.entrega_entrante, tipo_local_rm: r.tipo_local_rm, fab_direccion: r.fab_direccion, fab_comuna: r.fab_comuna, fab_contacto: r.fab_contacto, fab_telefono: r.fab_telefono }; });
  return m;
}
async function saveEstadoRetiro(docCompr, estado, tipoRetiro = null, entregaEntrante = null, extraFab = null) {
  const payload = { doc_compr: String(docCompr), estado, updated_by: await getUserEmail(), updated_at: new Date().toISOString() };
  if (tipoRetiro !== null) payload.tipo_retiro = tipoRetiro;
  if (entregaEntrante !== null) payload.entrega_entrante = entregaEntrante;
  if (extraFab) {
    if (extraFab.tipo_local_rm   !== undefined) payload.tipo_local_rm   = extraFab.tipo_local_rm;
    if (extraFab.fab_direccion   !== undefined) payload.fab_direccion   = extraFab.fab_direccion;
    if (extraFab.fab_comuna      !== undefined) payload.fab_comuna      = extraFab.fab_comuna;
    if (extraFab.fab_contacto    !== undefined) payload.fab_contacto    = extraFab.fab_contacto;
    if (extraFab.fab_telefono    !== undefined) payload.fab_telefono    = extraFab.fab_telefono;
    // Al revertir (no_coordinado), limpiar también tipo_retiro y entrega_entrante
    if (extraFab._clear_retiro) { payload.tipo_retiro = null; payload.entrega_entrante = null; }
  }
  const { error } = await supabase.from('abast_retiro_estado').upsert(payload, { onConflict: 'doc_compr' });
  if (error) { showAlert('Error al guardar estado: ' + error.message, 'error'); return false; }
  return true;
}
function showCoordModal(row) {
  return new Promise(async resolve => {
    const preselect = row._tipo_retiro || 'FAB-CD';
    const preselectLR = row._tipo_local_rm || 'RM';
    const opts = ['FAB-CD', 'FAB-SUC', 'FAB-CLTE'];
    // Pre-cargar direcciones del proveedor
    let dirs = [];
    try {
      const { data } = await supabase
        .from('abast_proveedor_direcciones')
        .select('id, nombre_fabrica, direccion, comuna')
        .eq('proveedor_id', row.proveedor ?? '')
        .eq('activo', true);
      dirs = data || [];
    } catch(_) {}

    const dirOpts = dirs.map(d =>
      `<option value="${d.id}" data-dir="${d.direccion || ''}" data-com="${d.comuna || ''}">${d.nombre_fabrica || d.direccion}</option>`
    ).join('');

    const radios = opts.map(o =>
      `<label class="flex items-center gap-2 cursor-pointer">
        <input type="radio" name="coord-tipo" value="${o}" ${o === preselect ? 'checked' : ''} class="accent-primary">
        <span class="font-semibold text-xs">${o}</span>
      </label>`
    ).join('');

    const html = `
      <div id="coord-modal-bg" class="fixed inset-0 bg-black/40 flex items-center justify-center z-[9999]">
        <div class="bg-white rounded-xl shadow-2xl p-6 w-[440px] flex flex-col gap-4 max-h-[90vh] overflow-y-auto">
          <h3 class="text-base font-bold text-gray-800">Confirmar Coordinación</h3>

          <div class="flex flex-col gap-1">
            <span class="text-xs font-semibold text-gray-500 uppercase tracking-wide">Tipo de Retiro</span>
            <div class="flex gap-3 mt-1">
              <button id="btn-local" class="flex-1 py-2 rounded-lg border-2 text-sm font-bold transition-all ${preselectLR === 'LOCAL' ? 'border-primary bg-primary/10 text-primary' : 'border-outline-variant text-secondary'}">RETIRO LOCAL</button>
              <button id="btn-rm"    class="flex-1 py-2 rounded-lg border-2 text-sm font-bold transition-all ${preselectLR === 'RM'    ? 'border-primary bg-primary/10 text-primary' : 'border-outline-variant text-secondary'}">RETIRO RM</button>
            </div>
            <input type="hidden" id="coord-local-rm" value="${preselectLR}">
          </div>

          <div id="fab-form" class="flex flex-col gap-3">
            <div class="flex flex-col gap-1">
              <label class="text-xs font-semibold text-gray-500 uppercase tracking-wide">Dirección de Fábrica</label>
              ${dirs.length > 0 ? `<select id="coord-dir-sel" class="border rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary">
                <option value="">— Seleccionar dirección guardada —</option>
                ${dirOpts}
                <option value="__manual__">+ Ingresar nueva dirección</option>
              </select>` : ''}
              <input id="coord-direccion" type="text" placeholder="Dirección" value="${row._fab_direccion || ''}"
                class="border rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary ${dirs.length > 0 ? 'hidden' : ''}">
            </div>
            <div class="flex gap-2">
              <div class="flex flex-col gap-1 flex-1">
                <label class="text-xs font-semibold text-gray-500 uppercase tracking-wide">Comuna</label>
                <input id="coord-comuna" type="text" placeholder="Comuna" value="${row._fab_comuna || ''}"
                  class="border rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary">
              </div>
            </div>
            <div class="flex gap-2">
              <div class="flex flex-col gap-1 flex-1">
                <label class="text-xs font-semibold text-gray-500 uppercase tracking-wide">Persona de Contacto</label>
                <input id="coord-contacto" type="text" placeholder="Nombre contacto" value="${row._fab_contacto || ''}"
                  class="border rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary">
              </div>
              <div class="flex flex-col gap-1 flex-1">
                <label class="text-xs font-semibold text-gray-500 uppercase tracking-wide">Teléfono</label>
                <input id="coord-telefono" type="text" placeholder="+56 9..." value="${row._fab_telefono || ''}"
                  class="border rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary">
              </div>
            </div>
            <label id="coord-guardar-prov-wrap" class="flex items-center gap-2 text-xs text-secondary cursor-pointer ${dirs.length > 0 ? 'hidden' : ''}">
              <input type="checkbox" id="coord-guardar-prov" checked class="accent-primary"> Guardar esta dirección en el proveedor
            </label>
          </div>

          <div id="entrega-wrap" class="flex flex-col gap-1 ${preselectLR !== 'RM' ? 'hidden' : ''}">
            <label for="coord-entrega" class="text-xs font-semibold text-gray-500 uppercase tracking-wide">Entrega Entrante SAP</label>
            <input id="coord-entrega" type="text" placeholder="Número SAP de entrega" value="${row._entrega_entrante || ''}"
              class="border rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary">
          </div>

          <div id="tipo-fab-wrap" class="flex flex-col gap-1 ${preselectLR !== 'RM' ? 'hidden' : ''}">
            <span class="text-xs font-semibold text-gray-500 uppercase tracking-wide">Clasificación Fábrica</span>
            <div class="flex gap-3 mt-1">${radios}</div>
          </div>

          <div class="flex gap-2 justify-end pt-1">
            <button id="coord-cancel" class="px-4 py-2 rounded-lg border text-sm hover:bg-gray-50">Cancelar</button>
            <button id="coord-confirm" class="px-4 py-2 rounded-lg bg-primary text-white text-sm font-semibold hover:opacity-90">Confirmar</button>
          </div>
        </div>
      </div>`;
    document.body.insertAdjacentHTML('beforeend', html);
    const bg = document.getElementById('coord-modal-bg');
    const cleanup = () => bg.remove();

    // Toggle LOCAL / RM
    const btnLocal = document.getElementById('btn-local');
    const btnRm    = document.getElementById('btn-rm');
    const inputLR  = document.getElementById('coord-local-rm');
    const entregaWrap = document.getElementById('entrega-wrap');
    const tipoFabWrap = document.getElementById('tipo-fab-wrap');
    function setLR(v) {
      inputLR.value = v;
      [btnLocal, btnRm].forEach(b => b.classList.remove('border-primary','bg-primary/10','text-primary'));
      [btnLocal, btnRm].forEach(b => b.classList.add('border-outline-variant','text-secondary'));
      const active = v === 'LOCAL' ? btnLocal : btnRm;
      active.classList.add('border-primary','bg-primary/10','text-primary');
      active.classList.remove('border-outline-variant','text-secondary');
      if (v === 'RM') { entregaWrap.classList.remove('hidden'); tipoFabWrap.classList.remove('hidden'); }
      else            { entregaWrap.classList.add('hidden');    tipoFabWrap.classList.add('hidden'); }
    }
    btnLocal.addEventListener('click', () => setLR('LOCAL'));
    btnRm.addEventListener('click',    () => setLR('RM'));

    // Selector de direcciones guardadas
    const dirSel = document.getElementById('coord-dir-sel');
    const inputDir = document.getElementById('coord-direccion');
    const inputCom = document.getElementById('coord-comuna');
    const inputCont = document.getElementById('coord-contacto');
    const inputTel  = document.getElementById('coord-telefono');
    const guardarWrap = document.getElementById('coord-guardar-prov-wrap');
    if (dirSel) {
      dirSel.addEventListener('change', () => {
        if (dirSel.value === '__manual__') {
          inputDir.classList.remove('hidden'); guardarWrap.classList.remove('hidden');
          inputDir.value = ''; inputCom.value = '';
        } else if (dirSel.value) {
          const opt = dirSel.options[dirSel.selectedIndex];
          inputDir.value = opt.dataset.dir || ''; inputCom.value = opt.dataset.com || '';
          inputDir.classList.add('hidden'); guardarWrap.classList.add('hidden');
        } else {
          inputDir.classList.add('hidden'); guardarWrap.classList.add('hidden');
        }
      });
      // Pre-seleccionar si ya había dirección guardada
      if (row._fab_direccion) {
        const match = dirs.find(d => d.direccion === row._fab_direccion);
        if (match) { dirSel.value = match.id; }
        else { dirSel.value = '__manual__'; inputDir.classList.remove('hidden'); guardarWrap.classList.remove('hidden'); }
      }
    }

    document.getElementById('coord-cancel').addEventListener('click', () => { cleanup(); resolve(null); });
    document.getElementById('coord-confirm').addEventListener('click', async () => {
      const tipoLocalRM    = inputLR.value;
      const tipoRetiro     = tipoLocalRM === 'RM' ? (bg.querySelector('input[name="coord-tipo"]:checked')?.value || preselect) : null;
      const entregaEntrante = tipoLocalRM === 'RM' ? (document.getElementById('coord-entrega')?.value || '').trim() : '';
      const fabDir  = inputDir  ? inputDir.value.trim()  : '';
      const fabCom  = inputCom  ? inputCom.value.trim()  : '';
      const fabCont = inputCont ? inputCont.value.trim() : '';
      const fabTel  = inputTel  ? inputTel.value.trim()  : '';

      // Guardar nueva dirección en proveedor si corresponde
      const guardarProv = document.getElementById('coord-guardar-prov');
      if (guardarProv && guardarProv.checked && fabDir && row.proveedor) {
        await supabase.from('abast_proveedor_direcciones').insert({
          proveedor_id: row.proveedor,
          nombre_fabrica: fabDir,
          direccion: fabDir,
          comuna: fabCom,
          activo: true,
        });
      }

      cleanup();
      resolve({ tipoRetiro, entregaEntrante, tipoLocalRM, fabDir, fabCom, fabCont, fabTel });
    });
  });
}
const ESTADO_OPTS = [
  { v: 'no_coordinado', l: 'No coordinado' },
  { v: 'coordinado',    l: 'Coordinado con proveedor' },
];

// ============================================================================
// VISTAS DE DATOS TRONCALES
// ============================================================================
const VISTAS_TRONCAL = {
  // ── QUIEBRES SUCURSAL (SLIM) ──────────────────────────────────────────────
  quiebres: {
    titulo: 'GESTIÓN TRONCALES – QUIEBRES SUCURSALES',
    vista: 'v_trc_slim_stock',
    chipFilter: { campo: 'centro', label: 'Centro' },
    extraChips: [{ campo: '_tipo_quiebre', label: 'Tipo de Quiebre' }],
    searchLabel: 'Buscar Orden de Compra',
    filtros: [],
    transform(rows) {
      return rows
        .filter(r => CENTROS_QUIEBRES.includes(String(r.centro ?? '').trim()))
        .map(r => {
          const sd = parseNum(r.stock_days);       // vacío → 0
          const tq = tipoQuiebre(sd);
          return { ...r, _desc_centro: getNombreCentro(r.centro), _sd_num: sd,
                   _tipo_quiebre: tq.txt, _tq_cls: tq.cls, _stock_days_disp: (String(r.stock_days ?? '').trim() === '' ? '0' : r.stock_days) };
        })
        .filter(r => r._sd_num <= 7)               // sólo SKU con ≤ 7 días
        .sort((a, b) => {
          const c = String(a.centro).localeCompare(String(b.centro));
          if (c !== 0) return c;
          const ab = abcRank(a.clase_abc) - abcRank(b.clase_abc);
          if (ab !== 0) return ab;
          return a._sd_num - b._sd_num;
        });
    },
    badges(rows) {
      let q = 0, c = 0, rev = 0;
      rows.forEach(r => { if (r._sd_num <= 3) q++; else if (r._sd_num <= 5) c++; else rev++; });
      return badgePill('SKU Quebrados (0-3)', q, 'bg-red-600 text-white') +
             badgePill('Stock Crítico (3-5)', c, 'bg-[#e65100] text-white') +
             badgePill('En Revisión (6-7)', rev, 'bg-[#f9a825] text-black');
    },
    columnas: [
      { key: 'centro', label: 'Centro' },
      { key: '_desc_centro', label: 'Descripción Centro' },
      { key: 'codigo_articulo', label: 'Código Artículo' },
      { key: 'descripcion', label: 'Descripción' },
      { key: '_stock_days_disp', label: 'StockDays', cls: 'text-right font-data-mono' },
      { key: 'clase_abc', label: 'Clase ABC', cls: 'text-center' },
      { key: '_tipo_quiebre', label: 'Tipo de Quiebre', badge: r => r._tq_cls },
    ],
  },

  // ── RETIROS DE FÁBRICA (Step 1) — agrupado por OC ─────────────────────────
  retiros: {
    titulo: 'GESTIÓN TRONCALES – RETIROS DE FÁBRICA',
    vista: 'v_trc_sqvi_retiros_fabrica',
    chipFilter: { campo: 'ce', label: 'Centro' },
    extraChips: [
      { campo: '_tipo_retiro', label: 'Tipo Retiro' },
      { campo: '_estado_lbl', label: 'Coordinación' },
      { campo: '_alerta', label: 'Alerta' },
    ],
    noBuscar: true,
    filtros: [{ campo: 'doc_compr', label: 'Buscar Orden de Compra', tipo: 'buscar' }, { campo: 'nombre_1', label: 'Buscar por Nombre de Proveedor', tipo: 'buscar' }],
    dateRange: { campo: 'fe_entrega', label: 'Rango Fecha de Entrega' },
    async preload() {
      const estados = await loadEstadosRetiro();
      // fetchAllRows pagina en paralelo (PostgREST capea a 1000 por defecto,
      // .limit(5000) no basta para una vista de 2853+ filas)
      const pvRows = await fetchAllRows('v_trc_pedidos_ventas_ref');
      const pvMap = {};
      pvRows.forEach(r => {
        const k = String(r.doc_ventas ?? '').trim();
        if (k && !pvMap[k]) pvMap[k] = r;
      });
      return { estados, pvMap };
    },
    editable: {
      key: '_estado', options: ESTADO_OPTS,
      async onChange(row, val, ctx) {
        let tipoRetiro = null, entregaEntrante = null, result = null;
        if (val === 'coordinado') {
          result = await showCoordModal(row);
          if (!result) return false;
          tipoRetiro = result.tipoRetiro;
          entregaEntrante = result.entregaEntrante || '';
        }
        // Si no se coordinó (o se revierte), limpiar campos de fábrica en DB
        const extraFab = result ? {
          tipo_local_rm: result.tipoLocalRM, fab_direccion: result.fabDir,
          fab_comuna: result.fabCom, fab_contacto: result.fabCont, fab_telefono: result.fabTel,
        } : { tipo_local_rm: null, fab_direccion: null, fab_comuna: null, fab_contacto: null, fab_telefono: null, _clear_retiro: true };
        const ok = await saveEstadoRetiro(row.doc_compr, val, tipoRetiro, entregaEntrante, extraFab);
        if (ok) {
          const oc = String(row.doc_compr);
          ctx.estados[oc] = { ...(ctx.estados[oc] || {}), estado: val };
          if (tipoRetiro !== null) { ctx.estados[oc].tipo_retiro = tipoRetiro; row._tipo_retiro = tipoRetiro; }
          if (entregaEntrante !== null) { ctx.estados[oc].entrega_entrante = entregaEntrante; row._entrega_entrante = entregaEntrante; }
          if (extraFab) {
            ctx.estados[oc].tipo_local_rm  = extraFab.tipo_local_rm;
            ctx.estados[oc].fab_direccion  = extraFab.fab_direccion;
            ctx.estados[oc].fab_comuna     = extraFab.fab_comuna;
            ctx.estados[oc].fab_contacto   = extraFab.fab_contacto;
            ctx.estados[oc].fab_telefono   = extraFab.fab_telefono;
            row._tipo_local_rm  = extraFab.tipo_local_rm || '';
            row._fab_direccion  = extraFab.fab_direccion || '';
            row._fab_comuna     = extraFab.fab_comuna    || '';
            row._fab_contacto   = extraFab.fab_contacto  || '';
            row._fab_telefono   = extraFab.fab_telefono  || '';
            // Al revertir: limpiar también tipo_retiro y entrega_entrante en memoria
            if (extraFab._clear_retiro) {
              ctx.estados[oc].tipo_retiro      = null;
              ctx.estados[oc].entrega_entrante = '';
              row._entrega_entrante = '';
              // Recalcular _tipo_retiro desde alm (revertir override de coordinación)
              const almV = String(row.alm ?? '').trim();
              row._tipo_retiro = almV === '4000' ? 'FAB-CD' : 'FAB-SUC';
            }
          }
          showAlert('Estado actualizado', 'success');
        }
        return ok;
      },
    },
    expand: {
      key: 'doc_compr', idKey: 'doc_compr', numCols: 3,
      headers: ['Orden de Compra','Contrato de Compra','Centro Destino','Nombre Cliente','Nombre Vendedor','Centro Expedición','Ruta','Tipo Retiro','Entrega Entrante','ID Material','Nombre Material','Cantidad Pedido','Cantidad Pendiente','Ton SKU'],
      build(row) {
        return (row._detalle || []).map(d => [
          d.doc_compr, row.contr, d.ce, row._pv_nombre_cliente, row._pv_nombre_vendedor, row._pv_ce_expedicion, row._pv_ruta, row._tipo_retiro, row._entrega_entrante, d.material, d.texto_breve, fmtNum(d.pedido, 1), fmtNum(d.pendiente, 1), fmtNum(d.ton, 4),
        ]);
      },
    },
    transform(rows, ctx) {
      const estados = (ctx && ctx.estados) || {};
      const pvMap = (ctx && ctx.pvMap) || {};
      const validas = rows
        .filter(r => !String(r.proveedor ?? '').startsWith('*'))
        .filter(r => String(r.contr ?? '').trim() !== '');
      // Agrupar por Orden de Compra (doc_compr)
      const g = new Map();
      validas.forEach(r => {
        const oc = String(r.doc_compr ?? '').trim();
        if (!oc) return;
        if (!g.has(oc)) g.set(oc, []);
        g.get(oc).push(r);
      });
      const out = [];
      for (const [oc, items] of g.entries()) {
        const f = items[0];
        const almVal = String(f.alm ?? '').trim();
        let ton = 0, pendienteTotal = 0, pedidoTotal = 0, revSaldo = false;
        const detalle = items.map(r => {
          const ctdP = parseNum(r.ctd_pedido), ctdE = parseNum(r.ctd_entregada);
          const pend = ctdP - ctdE;
          const t = calcTon(maxPesoDim(r.peso_bruto, r.tamano_dimens), pend);
          ton += t; pendienteTotal += pend; pedidoTotal += ctdP;
          if (ctdE > 0 && ctdE < ctdP) revSaldo = true;
          return { doc_compr: oc, ce: r.ce, material: r.material, texto_breve: r.texto_breve, pedido: ctdP, pendiente: pend, ton: t };
        });
        // Tipo de retiro (AJUSTE): 4000=FÁBRICA-CD (Consolidar CD), 2000=FÁBRICA-SUCURSAL
        // (Fábrica Directo). Si OC >=80% cap camión y tiene pedido de venta ⇒ FÁBRICA-CLIENTE.
        const tienePedidoVenta = String(f.documento ?? '').trim() !== '';
        const cap = getCapacidadCamion(f.ce);
        let tipoRetiro;
        if (ton >= cap * 0.80 && tienePedidoVenta) tipoRetiro = 'FAB-CLTE';
        else if (almVal === '4000') tipoRetiro = 'FAB-CD';
        else if (almVal === '2000') tipoRetiro = 'FAB-SUC';
        else tipoRetiro = 'FAB-SUC';
        const al = alertaFecha(f.fe_entrega, 5);
        const estObj = estados[oc] || {};
        const est = estObj.estado || 'no_coordinado';
        // Usar tipo_retiro guardado si existe (persistencia entre recargas)
        if (estObj.tipo_retiro) tipoRetiro = estObj.tipo_retiro;
        // Cross-reference con pedidos_ventas_dt
        const docPV = String(f.documento ?? '').trim();
        const pv = pvMap[docPV] || {};
        out.push({
          doc_compr: oc, contr: f.contr, proveedor: f.proveedor, nombre_1: f.nombre_1,
          ce: f.ce, _desc_centro: getNombreCentro(f.ce), alm: f.alm, documento: f.documento,
          fe_entrega: f.fe_entrega,
          _tipo_retiro: tipoRetiro,
          _cliente: tipoRetiro === 'FAB-CLTE',
          _consolidar: tipoRetiro === 'FAB-CD',
          _ton_num: ton, _ton_totales: fmtNum(ton, 4),
          _pendiente_total: pendienteTotal, _pedido_total: pedidoTotal,
          _vigencia: revSaldo ? 'REVISIÓN SALDO PEDIDO' : '',
          _revision_saldo: revSaldo,
          _alerta: al.txt, _alerta_cls: al.cls,
          _estado: est, _estado_lbl: (ESTADO_OPTS.find(o => o.v === est) || {}).l || 'No coordinado',
          _entrega_entrante: estObj.entrega_entrante || '',
          _tipo_local_rm: estObj.tipo_local_rm || '',
          _fab_direccion:  estObj.fab_direccion  || '',
          _fab_comuna:     estObj.fab_comuna     || '',
          _fab_contacto:   estObj.fab_contacto   || '',
          _fab_telefono:   estObj.fab_telefono   || '',
          _detalle: detalle,
          // Datos cruzados de Pedidos de Ventas
          _pv_denominacion: pv.denominacion || '',
          _pv_nombre_cliente: pv.nombre_1 || '',
          _pv_nombre_vendedor: pv.nombre || '',
          _pv_ce_expedicion: pv.psex || '',
          _pv_ruta: pv.ruta || '',
          // Comuna asociada a la ruta del Pedido de Ventas, según maestro de rutas
          _pv_comuna: lookupRuta(pv.ruta).comuna || '',
        });
      }
      return out.sort((a, b) => {
        const da = parseDateSAP(a.fe_entrega), db2 = parseDateSAP(b.fe_entrega);
        return (da || new Date(9999,0)) - (db2 || new Date(9999,0));
      });
    },
    badges(filas, chipSel) {
      const pend = filas.filter(r => (r._pendiente_total || 0) > 0).length;
      const scope = (chipSel && chipSel !== 'all') ? `Centro ${chipSel}` : 'Todos los centros';
      return badgePill(`OC pendientes por retirar · ${scope}`, pend, 'bg-primary text-white');
    },
    rowClsFn(r) { return r._cliente ? 'bg-green-50' : (r._revision_saldo ? 'bg-red-50' : ''); },
    columnas: [
      { key: 'doc_compr', label: 'Orden de Compra', expandable: true },
      { key: 'nombre_1', label: 'Nombre de Proveedor' },
      { key: 'ce', label: 'Centro Destino' },
      { key: 'alm', label: 'Almacén Destino' },
      { key: 'fe_entrega', label: 'Fecha de Retiro', cls: 'num-clear' },
      { key: '_ton_totales', label: 'Ton Totales', cls: 'text-right num-clear font-bold' },
      { key: 'documento', label: 'Pedido de Ventas' },
      { key: '_pv_denominacion', label: 'Tipo Expedición' },
      { key: '_vigencia', label: 'Vigencia OC', rawHtml: true,
        valueFn: r => r._revision_saldo ? '<span class="material-symbols-outlined text-[16px] text-red-700" title="Revisión Saldo Pedido">warning</span>' : '',
        clsFn: () => 'text-center' },
      { key: '_alerta', label: 'Alerta', rawHtml: true,
        valueFn: r => {
          if (r._alerta === 'PEDIDO ATRASADO') return '<span class="inline-block w-3 h-3 rounded-full bg-red-600" title="Pedido Atrasado"></span>';
          if (r._alerta === 'PRONTO A VENCER') return '<span class="inline-block w-3 h-3 rounded-full bg-[#e65100]" title="Pronto a Vencer"></span>';
          if (r.fe_entrega) return '<span class="inline-block w-3 h-3 rounded-full bg-green-500" title="Vigente"></span>';
          return '';
        },
        clsFn: () => 'text-center' },
      { key: '_entrega_entrante', label: 'Entrega Entrante' },
      { key: '_estado', label: 'Coordinación', editable: true },
    ],
  },

  // ── PEDIDOS DE VENTA CD (1003) — agrupado por pedido ──────────────────────
  pedidos_venta: {
    titulo: 'GESTIÓN TRONCALES – PEDIDOS DE VENTA CD (1003)',
    vista: 'v_trc_sqvi_pedidos_venta_1003',
    chipFilter: { campo: 'ofvta', label: 'Oficina de Ventas' },
    filtros: [{ campo: 'doc_ventas', label: 'Buscar Pedido de Venta', tipo: 'buscar' }],
    dateRange: { campo: 'fe_entrega', label: 'Rango Fecha de Entrega' },
    noBuscar: true,
    expand: {
      key: 'doc_ventas', idKey: 'doc_ventas',
      headers: ['Pedido de Venta','ID Vendedor','Ruta','Comuna Destino','Región Destino','ID Material','Nombre Material','Cantidad Pendiente','Ton SKU'],
      build(row) {
        return (row._detalle || []).map(d => [
          d.doc_ventas, d.deudor, d.ruta, d.comuna, d.region, d.material, d.nombre, fmtNum(d.pendiente, 0), fmtNum(d.ton, 3),
        ]);
      },
    },
    transform(rows) {
      // 1) MR sólo vacías  2) sólo con ruta
      const base = rows
        .filter(r => !String(r.mr ?? '').trim())
        .filter(r => String(r.ruta ?? '').trim() !== '');
      // 2) Dedup doc_ventas+material → fecha de entrega más lejana
      const dedup = new Map();
      base.forEach(r => {
        const k = `${r.doc_ventas}|${r.material}`;
        const ex = dedup.get(k);
        if (!ex) { dedup.set(k, r); return; }
        const dNew = parseDateSAP(r.fe_entrega), dOld = parseDateSAP(ex.fe_entrega);
        if (dNew && (!dOld || dNew >= dOld)) dedup.set(k, r);
      });
      // 3) Excluir líneas ya entregadas (entregada == confirmada); pendiente = conf - entreg
      const lineas = [];
      for (const r of dedup.values()) {
        const conf = parseNum(r.ctd_confirmada), entreg = parseNum(r.cantidad_entrg);
        const pend = conf - entreg;
        if (conf > 0 && entreg >= conf) continue;   // entregado completo → fuera
        if (pend <= 0) continue;
        const rl = lookupRuta(r.ruta);
        // (AJUSTE) peso mayor entre PESO NETO y tamaño/dimensión × unidades pendientes
        const pesoPos = maxPesoDim(r.peso_neto, r.tamano_dimens) * pend;
        lineas.push({ ...r, _pend: pend, _entreg: entreg, _conf: conf, _ton: pesoPos / 1000,
                      _comuna: rl.comuna, _region: rl.region,
                      _parcial: (entreg > 0 && entreg < conf) });
      }
      // 4) Agrupar por pedido de venta
      const g = new Map();
      lineas.forEach(r => {
        const k = String(r.doc_ventas ?? '').trim();
        (g.get(k) || g.set(k, []).get(k)).push(r);
      });
      const out = [];
      for (const [doc, items] of g.entries()) {
        const f = items[0];
        let ton = 0, parcial = false;
        let fmax = null;
        const detalle = items.map(r => {
          ton += r._ton;
          if (r._parcial) parcial = true;
          const d = parseDateSAP(r.fe_entrega);
          if (d && (!fmax || d > fmax)) fmax = d;
          return { doc_ventas: doc, deudor: r.deudor, ruta: r.ruta, comuna: r._comuna, region: r._region,
                   material: r.material, nombre: r.denominacion_de_posicion, pendiente: r._pend, ton: r._ton };
        });
        const feLbl = fmax ? `${String(fmax.getDate()).padStart(2,'0')}.${String(fmax.getMonth()+1).padStart(2,'0')}.${fmax.getFullYear()}` : f.fe_entrega;
        const al = alertaFecha(feLbl, 5);
        // Descarga en camino: si la comuna del pedido (según maestro de rutas)
        // está en la lista de comunas "en el camino" del centro destino.
        const comunasList = comunasEnCamino(f.ofvta);
        let enCamino = false, comunaCamino = '';
        for (const it of items) {
          if (comunasList.has(normTxt(it._comuna))) { enCamino = true; comunaCamino = it._comuna; break; }
        }
        out.push({
          doc_ventas: doc, ofvta: f.ofvta, creado_el: f.creado_el, deudor: f.deudor,
          fe_entrega: feLbl, _ton_num: ton, _ton_totales: fmtNum(ton, 3),
          _estado: parcial ? 'ENTREGA PARCIAL PENDIENTE' : '',
          _alerta: al.txt, _alerta_cls: al.cls, _detalle: detalle,
          _en_camino: enCamino,
          _camino_lbl: enCamino ? `DESCARGA EN CAMINO (${comunaCamino})` : '',
        });
      }
      return out.sort((a, b) => {
        const da = parseDateSAP(a.fe_entrega), db2 = parseDateSAP(b.fe_entrega);
        return (da || new Date(9999,0)) - (db2 || new Date(9999,0));
      });
    },
    // Tipo de entrega: ≥80% cap camión ⇒ CD-CLIENTE (camión directo al cliente);
    // menos ⇒ CD-SUCURSAL (se consolida con carga).
    postFilter(filas) {
      filas.forEach(r => {
        const cap = getCapacidadCamion(r.ofvta);
        r._directo = r._ton_num >= cap * 0.80;
        r._tipo_entrega = r._directo ? 'CD-CLIENTE' : 'CD-SUCURSAL';
      });
      return filas;
    },
    rowClsFn(r) { return r._directo ? 'bg-green-50' : ''; },
    columnas: [
      { key: '_tipo_entrega', label: 'Tipo de Entrega', clsFn: r => r._directo ? 'text-green-800 font-bold' : 'text-blue-700 font-bold' },
      { key: 'ofvta', label: 'Oficina de Ventas' },
      { key: 'creado_el', label: 'Fecha de Creación' },
      { key: 'deudor', label: 'ID Vendedor' },
      { key: 'doc_ventas', label: 'Pedido de Venta', expandable: true },
      { key: 'fe_entrega', label: 'Fecha de Entrega', cls: 'num-clear' },
      { key: '_ton_totales', label: 'Toneladas Totales', cls: 'text-right num-clear font-bold' },
      { key: '_camino_lbl', label: 'Descarga en Camino', clsFn: () => 'text-teal-700 font-bold' },
      { key: '_estado', label: 'Estado', clsFn: () => 'text-[#e65100] font-bold' },
      { key: '_alerta', label: 'Alerta', clsFn: r => r._alerta_cls },
    ],
  },

  // ── PEDIDOS TRASLADOS (Step 4) ────────────────────────────────────────────
  pedidos_traslados: {
    titulo: 'GESTIÓN TRONCALES – PEDIDOS TRASLADOS',
    vista: 'v_trc_sqvi_pedidos_traslados',
    chipFilter: { campo: 'ce', label: 'Centro Destino' },
    extraChips: [{ campo: 'cesu', label: 'Centro Origen' }],
    noBuscar: true,
    filtros: [{ campo: 'doc_compr', label: 'Buscar Pedido de Traslado', tipo: 'buscar' }],
    dateRange: { campo: 'fecha_confirmada', label: 'Rango Fecha Confirmada' },
    async preload() {
      const stockRows = await fetchAllRows('v_trc_slim_stock');
      // Mapa quiebres: "centro|codigo_articulo" → { sd, tq } para SKU con stock_days ≤ 7
      const quiebresMap = {};
      stockRows.forEach(r => {
        const sd = parseNum(r.stock_days);
        if (sd > 7) return;
        const k = `${String(r.centro ?? '').trim()}|${String(r.codigo_articulo ?? '').trim()}`;
        if (!quiebresMap[k]) quiebresMap[k] = { sd, tq: tipoQuiebre(sd) };
      });
      return { quiebresMap };
    },
    transform(rows, ctx) {
      const quiebresMap = (ctx && ctx.quiebresMap) || {};
      const validas = rows
        .filter(r => !String(r.cesu ?? '').startsWith('*') && String(r.material ?? '').trim() !== '')
        .filter(r => !String(r.material ?? '').startsWith('900000'));
      function alertaIconHtml(al) {
        if (!al.txt) return '<span class="material-symbols-outlined text-green-600 text-[16px] align-middle" title="OK">check_circle</span>';
        if (al.txt === 'PEDIDO ATRASADO')
          return '<span class="material-symbols-outlined text-error text-[16px] align-middle">cancel</span> <span class="text-error font-bold text-[11px]">ATRASADO</span>';
        return '<span class="material-symbols-outlined text-[#e65100] text-[16px] align-middle">warning</span> <span class="text-[#e65100] font-bold text-[11px]">PRONTO A VENCER</span>';
      }
      function quiebreBadgeHtml(q) {
        if (!q) return '';
        const short = q.tq.txt === 'MATERIAL QUEBRADO URGENTE' ? 'QUIEBRE'
                    : q.tq.txt === 'STOCK CRÍTICO URGENTE'     ? 'CRÍTICO'
                    : 'EN REVISIÓN';
        return `<span class="inline-flex items-center gap-[3px] px-[6px] py-[2px] rounded-full text-[11px] font-bold ${q.tq.cls}">` +
               `<span class="material-symbols-outlined text-[13px]">inventory_2</span>${short} (${q.sd}d)</span>`;
      }
      const out = validas.map(r => {
        const al = alertaFecha(r.fecha_confirmada, 7);
        const t = calcTon(maxPesoDim(r.peso_neto, r.tamano_dimens), r.ctd_confirmada);
        const kq = `${String(r.ce ?? '').trim()}|${String(r.material ?? '').trim()}`;
        const q = quiebresMap[kq] || null;
        return {
          doc_compr: String(r.doc_compr ?? '').trim(),
          cesu: r.cesu, ce: r.ce, alm: r.alm,
          material: r.material, texto_breve: r.texto_breve,
          fecha_confirmada: r.fecha_confirmada,
          ctd_pedido: r.ctd_pedido,
          _ton_sku: fmtNum(t, 4),
          documento: r.documento,
          _alerta: al.txt, _alerta_cls: al.cls,
          _alerta_icon: alertaIconHtml(al),
          _quiebre_badge: quiebreBadgeHtml(q),
          _en_quiebre: !!q,
        };
      });
      // Ordenar: primero los que tienen quiebre, luego por fecha
      return out.sort((a, b) => {
        if (a._en_quiebre !== b._en_quiebre) return a._en_quiebre ? -1 : 1;
        const da = parseDateSAP(a.fecha_confirmada), db2 = parseDateSAP(b.fecha_confirmada);
        return (da || new Date(9999,0)) - (db2 || new Date(9999,0));
      });
    },
    rowClsFn(r) { return r._en_quiebre ? 'bg-red-50' : ''; },
    columnas: [
      { key: '_alerta_icon', label: 'Alerta', rawHtml: true },
      { key: '_quiebre_badge', label: 'Estado Quiebre', rawHtml: true },
      { key: 'doc_compr', label: 'Pedido de Traslado' },
      { key: 'cesu', label: 'Centro Origen' },
      { key: 'ce', label: 'Centro Destino' },
      { key: 'alm', label: 'Almacén Destino' },
      { key: 'material', label: 'ID Material' },
      { key: 'texto_breve', label: 'Nombre Material' },
      { key: 'fecha_confirmada', label: 'Fecha Confirmada', cls: 'num-clear' },
      { key: 'ctd_pedido', label: 'Cantidad Pedido', cls: 'text-right num-clear' },
      { key: '_ton_sku', label: 'Total SKU', cls: 'text-right num-clear font-bold' },
      { key: 'documento', label: 'Pedido de Ventas' },
    ],
  },

  // ── PEDIDOS DE TRASLADO REVEX (material 900000) ───────────────────────────
  pedidos_traslados_revex: {
    titulo: 'GESTIÓN TRONCALES – PEDIDOS DE TRASLADO REVEX',
    vista: 'v_trc_sqvi_pedidos_traslados',
    chipFilter: { campo: 'ce', label: 'Centro Destino' },
    noBuscar: true,
    filtros: [{ campo: 'doc_compr', label: 'BUSCAR PEDIDO DE TRASLADO', tipo: 'buscar' }],
    dateRange: { campo: 'fecha_confirmada', label: 'Rango Fecha Confirmada' },
    transform(rows) {
      return rows
        .filter(r => String(r.material ?? '').startsWith('900000'))
        .map(r => {
          const al = alertaFecha(r.fecha_confirmada, 7);
          // (AJUSTE) Ton = segunda columna de peso neto (peso_neto_2) × cantidad pedida.
          const pm = parseNum(r.peso_neto_2);
          return { ...r, _ton_totales: fmtNum(calcTon(pm, r.ctd_pedido), 4), _alerta: al.txt, _alerta_cls: al.cls };
        })
        .sort((a, b) => {
          const da = parseDateSAP(a.fecha_confirmada), db2 = parseDateSAP(b.fecha_confirmada);
          return (da || new Date(9999,0)) - (db2 || new Date(9999,0));
        });
    },
    columnas: [
      { key: 'cesu', label: 'Centro Expedición' },
      { key: 'creado_el', label: 'Fecha de Creación' },
      { key: 'cl', label: 'Tipo de Documento' },
      { key: 'doc_compr', label: 'Pedido de Traslado' },
      { key: 'material', label: 'ID Material' },
      { key: 'texto_breve', label: 'Nombre Material' },
      { key: 'ce', label: 'Centro Destino' },
      { key: 'alm', label: 'Almacén Destino' },
      { key: 'ctd_pedido', label: 'Ctd Pedido', cls: 'text-right num-clear' },
      { key: 'ump', label: 'UM Pedido' },
      { key: 'fecha_confirmada', label: 'Fecha Confirmada', cls: 'num-clear' },
      { key: '_ton_totales', label: 'Ton Totales', cls: 'text-right num-clear font-bold' },
      { key: '_alerta', label: 'Alerta', clsFn: r => r._alerta_cls },
    ],
  },

  // ── STOCK ALMACÉN 4000 (unifica Stock + Plan Troncales) ───────────────────
  stock_almacen: {
    titulo: 'GESTIÓN TRONCALES – STOCK ALMACÉN 4000',
    chipFilter: { campo: 'ce', label: 'Centro' },
    modes: [
      {
        id: 'stock', label: 'STOCK',
        vista: 'v_trc_sqvi_plan_troncales',
        transform(rows) {
          return rows
            .filter(r => String(r.material ?? '').trim() !== '')
            .filter(r => !String(r.ce ?? '').startsWith('*'))
            .map(r => {
              const pm = maxPesoDim(r.peso_bruto, r.tamano_dimens);
              return { ...r, _peso_mayor: fmtNum(pm, 2), _ton_totales: fmtNum(calcTon(pm, r.libre_utiliz), 3) };
            });
        },
        columnas: [
          { key: 'ce', label: 'Centro Destino' },
          { key: 'alm', label: 'Almacén Destino' },
          { key: 'material', label: 'ID Material' },
          { key: 'texto_breve_de_material', label: 'Nombre Material' },
          { key: 'umb', label: 'UN Pedido' },
          { key: 'libre_utiliz', label: 'Cantidad Disponible', cls: 'text-right font-data-mono' },
          { key: '_peso_mayor', label: 'Peso Mayor', cls: 'text-right font-data-mono' },
          { key: '_ton_totales', label: 'Toneladas Totales', cls: 'text-right font-data-mono font-bold' },
        ],
      },
      {
        id: 'pedidos', label: 'PEDIDO DE VENTAS',
        vista: 'v_trc_sqvi_stock_almacen_4000',
        transform(rows) {
          return rows.map(r => {
            const rl = lookupRuta(r.ruta);
            const pm = maxPesoDim(r.peso_bruto, r.tamano_dimens);
            return { ...r, _comuna: rl.comuna, _region: rl.region, _peso_mayor: fmtNum(pm, 2), _ton_totales: fmtNum(calcTon(pm, r.libre_utiliz), 3) };
          });
        },
        columnas: [
          { key: 'ce', label: 'Centro Destino' },
          { key: 'alm', label: 'Almacén Destino' },
          { key: 'material', label: 'ID Material' },
          { key: 'denominacion_de_posicion', label: 'Nombre Material' },
          { key: 'libre_utiliz', label: 'Cantidad Disponible', cls: 'text-right font-data-mono' },
          { key: 'umb', label: 'UM Pedido' },
          { key: 'ruta', label: 'Ruta' },
          { key: '_comuna', label: 'Comuna' },
          { key: '_region', label: 'Región' },
          { key: 'deudor', label: 'ID Vendedor' },
          { key: 'documento', label: 'Pedido de Ventas' },
          { key: 'creado', label: 'Fecha de Entrega' },
          { key: '_peso_mayor', label: 'Peso Mayor', cls: 'text-right font-data-mono' },
          { key: '_ton_totales', label: 'Toneladas Totales', cls: 'text-right font-data-mono font-bold' },
        ],
      },
    ],
  },

  // ── PEDIDOS DE TRASLADOS 4000 (Step 5) — agrupado por PT ──────────────────
  pedidos_traslados_4000: {
    titulo: 'GESTIÓN TRONCALES – PEDIDOS DE TRASLADOS 4000',
    vista: 'v_trc_sqvi_pedidos_traslados_4000',
    chipFilter: { campo: 'ce', label: 'Centro Destino' },
    extraChips: [{ campo: '_origen', label: 'Origen' }],
    noBuscar: true,
    filtros: [{ campo: 'doc_compr', label: 'Buscar Pedido de Traslado', tipo: 'buscar' }],
    dateRange: { campo: 'fe_entrega', label: 'Rango Fecha de Entrega' },
    async preload() {
      const pvRows = await fetchAllRows('v_trc_pedidos_ventas_ref');
      const pvMap = {};
      pvRows.forEach(r => {
        const k = String(r.doc_ventas ?? '').trim();
        if (k && !pvMap[k]) pvMap[k] = r;
      });
      return { pvMap };
    },
    transform(rows, ctx) {
      const pvMap = (ctx && ctx.pvMap) || {};
      // Deduplicar por doc_compr|pos, preferir fecha válida sobre '00.00.0000'
      const esValida = fe => fe && String(fe).trim() !== '' && String(fe).trim() !== '00.00.0000';
      const _dedupMap = new Map();
      rows.forEach(r => {
        const dc = String(r.doc_compr ?? '').trim();
        const pos = String(r.pos ?? '').trim();
        if (!dc || !String(r.material ?? '').trim()) return;
        const k = `${dc}|${pos}`;
        const ex = _dedupMap.get(k);
        if (!ex || (!esValida(ex.fe_entrega) && esValida(r.fe_entrega))) _dedupMap.set(k, r);
      });
      const validas = Array.from(_dedupMap.values())
        .filter(r => String(r.cesu ?? '').trim() !== '' && !String(r.cesu ?? '').startsWith('*'))
        .filter(r => String(r.material ?? '').trim() !== '')
        .filter(r => parseNum(r.ctd_pedido) > parseNum(r.cantidad_salida));
      const out = validas.map(r => {
        const pend = parseNum(r.ctd_pedido) - parseNum(r.cantidad_salida);
        const t = calcTon(maxPesoDim(r.peso_neto, r.tamano_dimens), pend);
        const origen = String(r.documento ?? '').trim() ? 'PEDIDO DE VENTAS' : 'STOCK';
        const docPV = String(r.documento ?? '').trim();
        const pv = pvMap[docPV] || {};
        return {
          doc_compr: String(r.doc_compr ?? '').trim(),
          cesu: r.cesu, ce: r.ce, alm: r.alm,
          fe_entrega: r.fe_entrega,
          material: r.material,
          texto_breve: r.texto_breve,
          _ctd_pend: fmtNum(pend, 1),
          _ton_sku: fmtNum(t, 4),
          documento: r.documento,
          _origen: origen,
          _ton_num: t,
          // (FIX) Tipo de Expedición es pv.denominacion (ej. FAB-DESP, CLI-RET);
          // pv.psex es el código de Centro de Expedición, antes mostrado por error acá.
          _tipo_exp: pv.denominacion || '',
          _centro_exp: pv.psex || '',
          _ruta: pv.ruta || '',
          _comuna: lookupRuta(pv.ruta).comuna || '',
          _vendedor: pv.nombre || '',
        };
      });
      return out.sort((a, b) => {
        const da = parseDateSAP(a.fe_entrega), db2 = parseDateSAP(b.fe_entrega);
        return (da || new Date(9999,0)) - (db2 || new Date(9999,0));
      });
    },
    columnas: [
      { key: '_origen', label: 'Origen', clsFn: r => r._origen === 'PEDIDO DE VENTAS' ? 'text-blue-700 font-bold' : 'text-green-700 font-bold' },
      { key: 'doc_compr', label: 'Pedido de Traslado' },
      { key: 'ce', label: 'Centro Destino' },
      { key: 'alm', label: 'Almacén Destino' },
      { key: 'fe_entrega', label: 'Fecha de Entrega', cls: 'num-clear' },
      { key: 'material', label: 'ID Material' },
      { key: 'texto_breve', label: 'Nombre Material' },
      { key: '_ctd_pend', label: 'Cant. Pendiente', cls: 'text-right num-clear' },
      { key: '_ton_sku', label: 'Ton SKU', cls: 'text-right num-clear' },
      { key: 'documento', label: 'Pedido de Ventas' },
      { key: '_tipo_exp', label: 'Tipo de Expedición' },
      { key: '_centro_exp', label: 'Centro Expedición' },
      { key: '_ruta', label: 'ID Ruta' },
      { key: '_comuna', label: 'Comuna' },
      { key: '_vendedor', label: 'Nombre de Vendedor' },
    ],
  },

  // ── DOCUMENTOS DE TRANSPORTE (Job ZJC PLAN DT, Step 1) ─────────────────────
  // Agrupado por Transporte (nro transporte). Drill-down muestra entregas/materiales.
  documentos_transporte: {
    titulo: 'GESTIÓN TRONCALES – DOCUMENTOS DE TRANSPORTE',
    vista: 'v_trc_dt_transportes',
    chipFilter: { campo: '_centro_destino', label: 'Centro' },
    extraChips: [{ campo: 'ruta', label: 'Ruta' }],
    searchLabel: 'BUSCADOR GENERAL',
    filtros: [],
    dateRange: { campo: 'fe_entrega', label: 'Rango Fecha de Entrega' },
    expand: {
      key: 'transporte', idKey: 'transporte', numCols: 2,
      headers: ['Entrega','Material','Descripción','Cantidad','UM','Doc. Compra','Hoja Entrega'],
      build(row) {
        return (row._detalle || []).map(d => [
          d.entrega, d.material, d.denominacion_de_posicion,
          d.cantidad_entrega, d.um, d.doc_compr, d.hoja_entr,
        ]);
      },
    },
    transform(rows) {
      // Filtrar filas vacías
      const validas = rows.filter(r => String(r.transporte ?? '').trim() !== '');
      // Agrupar por Transporte
      const g = new Map();
      validas.forEach(r => {
        const t = String(r.transporte ?? '').trim();
        if (!t) return;
        (g.get(t) || g.set(t, []).get(t)).push(r);
      });
      const out = [];
      for (const [trp, items] of g.entries()) {
        const f = items[0];
        const entregas = [...new Set(items.map(i => String(i.entrega ?? '').trim()).filter(Boolean))];
        // Calcular toneladas si hay peso
        let tonTotal = 0;
        const detalle = items.map(r => {
          const qty = parseNum(r.cantidad_entrega);
          return {
            entrega: r.entrega, material: r.material,
            denominacion_de_posicion: r.denominacion_de_posicion,
            cantidad_entrega: r.cantidad_entrega, um: r.um,
            doc_compr: r.doc_compr, hoja_entr: r.hoja_entr,
          };
        });
        // Extraer centro destino del destinatario o del primer dígito de ruta
        const centroDestino = String(f.destinat ?? '').trim();
        out.push({
          transporte: trp,
          cltr: f.cltr,
          denominacion: f.denominacion,
          denom_transporte: f.denom_transporte,
          agservtran: f.agservtran,
          nombre_1: f.nombre_1,
          creado_el: f.creado_el,
          ruta: f.ruta,
          fe_entrega: f.fe_entrega,
          _centro_destino: centroDestino,
          _num_entregas: entregas.length,
          _num_materiales: items.length,
          _entregas_list: entregas.join(', '),
          _detalle: detalle,
        });
      }
      // Ordenar por fecha entrega (más próxima primero)
      return out.sort((a, b) => {
        const da = parseDateSAP(a.fe_entrega), db2 = parseDateSAP(b.fe_entrega);
        return (da || new Date(9999,0)) - (db2 || new Date(9999,0));
      });
    },
    columnas: [
      { key: 'transporte', label: 'N° Transporte', expandable: true },
      { key: 'denominacion', label: 'Tipo Transporte' },
      { key: 'nombre_1', label: 'Transportista' },
      { key: 'ruta', label: 'Ruta' },
      { key: '_centro_destino', label: 'Destinatario' },
      { key: 'fe_entrega', label: 'Fecha Entrega', cls: 'num-clear' },
      { key: '_num_entregas', label: 'Entregas', cls: 'text-center font-bold' },
      { key: '_num_materiales', label: 'Materiales', cls: 'text-center' },
    ],
  },

  // ── ENTREGAS CREADAS (Job ZJC PLAN ENTREGAS, Step 1) ───────────────────────
  // Agrupado por Entrega. Drill-down muestra materiales de cada entrega.
  entregas_creadas: {
    titulo: 'GESTIÓN TRONCALES – ENTREGAS CREADAS',
    vista: 'v_trc_entregas_creadas',
    chipFilter: { campo: 'ce', label: 'Centro' },
    extraChips: [{ campo: 'ruta', label: 'Ruta' }, { campo: 'clent', label: 'Clase Entrega' }],
    searchLabel: 'BUSCADOR GENERAL',
    filtros: [],
    dateRange: { campo: 'creado_el', label: 'Rango Fecha Creación' },
    expand: {
      key: 'entrega', idKey: 'entrega', numCols: 2,
      headers: ['Material','Descripción','Cantidad Entrega','UM','Doc. Modelo','Pos. Modelo'],
      build(row) {
        return (row._detalle || []).map(d => [
          d.material, d.denominacion_de_posicion,
          d.cantidad_entrega, d.um, d.doc_modelo, d.posmod,
        ]);
      },
    },
    transform(rows) {
      const validas = rows.filter(r => String(r.entrega ?? '').trim() !== '');
      // Agrupar por Entrega
      const g = new Map();
      validas.forEach(r => {
        const e = String(r.entrega ?? '').trim();
        if (!e) return;
        (g.get(e) || g.set(e, []).get(e)).push(r);
      });
      const out = [];
      for (const [ent, items] of g.entries()) {
        const f = items[0];
        const rl = lookupRuta(f.ruta);
        const detalle = items.map(r => ({
          material: r.material,
          denominacion_de_posicion: r.denominacion_de_posicion,
          cantidad_entrega: r.cantidad_entrega,
          um: r.um, doc_modelo: r.doc_modelo, posmod: r.posmod,
        }));
        out.push({
          entrega: ent,
          creado_por: f.creado_por,
          creado_el: f.creado_el,
          clent: f.clent,
          tpdoc: f.tpdoc,
          ce: f.ce,
          psex: f.psex,
          ruta: f.ruta,
          _comuna: rl.comuna,
          _region: rl.region,
          clvt: f.clvt,
          doc_modelo: f.doc_modelo,
          _num_materiales: items.length,
          _detalle: detalle,
        });
      }
      // Ordenar por fecha creación descendente (más reciente primero)
      return out.sort((a, b) => {
        const da = parseDateSAP(a.creado_el), db2 = parseDateSAP(b.creado_el);
        return (db2 || new Date(0)) - (da || new Date(0));
      });
    },
    columnas: [
      { key: 'entrega', label: 'N° Entrega', expandable: true },
      { key: 'creado_por', label: 'Creado Por' },
      { key: 'creado_el', label: 'Fecha Creación', cls: 'num-clear' },
      { key: 'clent', label: 'Clase Entrega' },
      { key: 'ce', label: 'Centro' },
      { key: 'ruta', label: 'Ruta' },
      { key: '_comuna', label: 'Comuna' },
      { key: '_region', label: 'Región' },
      { key: 'clvt', label: 'Clase Venta' },
      { key: 'doc_modelo', label: 'Doc. Modelo' },
      { key: '_num_materiales', label: 'Materiales', cls: 'text-center font-bold' },
    ],
  },

};

// Etiqueta contadora (badge)
function badgePill(label, count, cls) {
  return `<span class="inline-flex items-center gap-xs px-sm py-xs rounded-full text-[12px] font-bold ${cls}">
    <span class="material-symbols-outlined text-[15px]">label_important</span>${escapeHtml(label)}: ${count}</span>`;
}

// ============================================================================
// ENTRADA PRINCIPAL
// ============================================================================
export async function renderAbastecimientoView(container) {
  rootEl = container;
  container.innerHTML = '<div id="ab-stage"></div>';
  const stage = container.querySelector('#ab-stage');
  if (currentSub === 'calendario')          await renderCalendario(stage);
  else if (currentSub === 'plan_carga')      await renderPlanCarga(stage);
  else if (VISTAS_TRONCAL[currentSub])       await renderVistaTabla(stage, VISTAS_TRONCAL[currentSub]);
  else                                       await renderProveedores(stage);
}

// Caché en memoria de filas crudas por vista (evita recargar al cambiar de
// pestaña o al reusar la misma vista en el Plan de Carga).
const _rawCache = new Map();       // vista -> { rows, ts }
const RAW_TTL = 120000;            // 2 minutos
function clearRawCache() { _rawCache.clear(); }

async function fetchAllRows(vista, force = false) {
  const cached = _rawCache.get(vista);
  if (!force && cached && (Date.now() - cached.ts) < RAW_TTL) return cached.rows;

  const pageSize = 1000;
  // 1) Total de filas (HEAD, sin traer datos) para paginar en paralelo.
  //    OJO: si el count falla o vuelve null (pasa con vistas DISTINCT ON /
  //    RLS), NO hay que asumir que todo cabe en 1 página — eso trunca en
  //    silencio a 1000 filas y descarta el resto sin error visible. Por eso
  //    el paso 3 (barrido de seguridad) valida esto siempre.
  let total = 0;
  try {
    const { count, error } = await supabase.from(vista).select('*', { count: 'exact', head: true });
    if (!error && typeof count === 'number') total = count;
  } catch { total = 0; }

  let rows = [];
  if (total > pageSize) {
    // 2) Traer todas las páginas EN PARALELO (mucho más rápido que secuencial)
    const pages = Math.min(Math.ceil(total / pageSize), 200);
    const reqs = [];
    for (let p = 0; p < pages; p++) {
      reqs.push(supabase.from(vista).select('*').range(p * pageSize, p * pageSize + pageSize - 1));
    }
    const results = await Promise.all(reqs);
    for (const { data, error } of results) {
      if (error) { console.error(error); continue; }
      if (data) rows = rows.concat(data);
    }
  } else {
    const { data, error } = await supabase.from(vista).select('*').range(0, pageSize - 1);
    if (error) { console.error(error); showAlert('Error al cargar datos: ' + error.message, 'error'); return cached ? cached.rows : []; }
    rows = data || [];
  }

  // 3) Barrido de seguridad: si el count del paso 1 fue erróneo/menor al
  //    real (o falló y quedó en 0), la última página recibida viene COMPLETA
  //    (exactamente pageSize filas). En ese caso puede haber más datos
  //    detrás: seguir pidiendo páginas siguientes hasta recibir una
  //    incompleta o vacía. Esto es lo que evita que un count fallido trunque
  //    el resultado en 1000 filas sin avisar (el bug que dejaba pedidos de
  //    venta reales fuera del cruce con Retiros de Fábrica).
  let nextOffset = rows.length;
  let guard = 0;
  while (rows.length > 0 && rows.length % pageSize === 0 && guard < 200) {
    const { data, error } = await supabase.from(vista).select('*').range(nextOffset, nextOffset + pageSize - 1);
    if (error) { console.error(error); break; }
    if (!data || data.length === 0) break;
    rows = rows.concat(data);
    nextOffset += data.length;
    guard++;
    if (data.length < pageSize) break;
  }

  _rawCache.set(vista, { rows, ts: Date.now() });
  return rows;
}

// ============================================================================
// PLAN DE CARGA — Dashboard de consolidación por sucursal
// ============================================================================
const CAP_CAMION_DEFAULT = 28;
const CAP_CAMION_REDUCIDO = 15;
const CENTROS_CAMION_REDUCIDO = ['1050', '1005'];

function getCapacidadCamion(centroId) {
  return CENTROS_CAMION_REDUCIDO.includes(String(centroId)) ? CAP_CAMION_REDUCIDO : CAP_CAMION_DEFAULT;
}

function getCentrosProgramados(calendarioRows, diaNum) {
  const programados = new Set();
  calendarioRows
    .filter(r => Number(r.dia) === diaNum && (r.habilitado === true || r.habilitado === 'true'))
    .forEach(r => {
      if (r.centro_destino_1) programados.add(String(r.centro_destino_1).trim());
      if (r.centro_destino_2) programados.add(String(r.centro_destino_2).trim());
    });
  return programados;
}

function fechaEnRango(fechaStr, diasAntes, diasDespues) {
  const d = parseDateSAP(fechaStr);
  if (!d) return false;
  const hoy = hoy00();
  const diff = Math.floor((d - hoy) / 86400000);
  return diff >= -diasAntes && diff <= diasDespues;
}

let planDetalleAbierto = new Set();
let planOrigen = '1003';   // centro origen del plan de carga (1003 / 1081)

async function renderPlanCarga(stage) {
  stage.innerHTML = '<div class="text-secondary text-body-md p-md">Cargando Plan de Carga…</div>';

  const [quiebresRaw, trasladosRaw, revexRaw, retirosRaw, ventasRaw, traslados4000Raw, calendarioRows, estadosRetiro] = await Promise.all([
    fetchAllRows('v_trc_slim_stock'),
    fetchAllRows('v_trc_sqvi_pedidos_traslados'),
    fetchAllRows('v_trc_sqvi_pedidos_traslados'),
    fetchAllRows('v_trc_sqvi_retiros_fabrica'),
    fetchAllRows('v_trc_sqvi_pedidos_venta_1003'),
    fetchAllRows('v_trc_sqvi_pedidos_traslados_4000'),
    fetchAllRows('abast_calendario'),
    loadEstadosRetiro(),
  ]);

  // Materiales quebrados por centro (≤7 días)
  const quiebresByCentro = {};
  quiebresRaw
    .filter(r => CENTROS_QUIEBRES.includes(String(r.centro ?? '').trim()))
    .forEach(r => {
      const ce = String(r.centro).trim();
      const sd = parseNum(r.stock_days);
      if (sd <= 7) {
        if (!quiebresByCentro[ce]) quiebresByCentro[ce] = new Set();
        quiebresByCentro[ce].add(String(r.codigo_articulo ?? '').trim());
      }
    });

  // (AJUSTE) Plan de carga por CENTRO ORIGEN: sólo se consideran los pedidos de
  // traslado cuyo centro de expedición (cesu) sea el origen seleccionado (1003 o
  // 1081). Ventas 1003 y retiros sólo aplican al plan del CD 1003.
  const esCD1003 = planOrigen === '1003';
  const traslados = trasladosRaw
    .filter(r => !String(r.cesu ?? '').startsWith('*') && String(r.material ?? '').trim() !== '')
    .filter(r => !String(r.material ?? '').startsWith('900000'))
    .filter(r => String(r.cesu ?? '').trim() === planOrigen);
  const revex = revexRaw
    .filter(r => String(r.material ?? '').startsWith('900000'))
    .filter(r => String(r.cesu ?? '').trim() === planOrigen);
  // REVEX: cesu = centro origen (1003 o 1081), ce = centro destino donde se contabiliza
  const retiros = esCD1003 ? retirosRaw
    .filter(r => !String(r.proveedor ?? '').startsWith('*'))
    .filter(r => String(r.contr ?? '').trim() !== '')
    .filter(r => { const _e = estadosRetiro[String(r.doc_compr ?? '').trim()] || {}; return _e.estado === 'coordinado' && (_e.tipo_local_rm === 'RM' || String(_e.entrega_entrante ?? '').trim() !== ''); }) : [];
  const ventas = esCD1003 ? ventasRaw.filter(r => !String(r.mr ?? '').trim()) : [];
  // sqvi_pedidos_traslados_4000: cesu==ce (destino), origen siempre es CD 1003.
  // Deduplicar por doc_compr|pos — clave sin fecha para fusionar la fila '00.00.0000'
  // (cabecera SAP) con la fila de fecha real (línea de planificación), conservando
  // siempre la fecha válida. Excluir subtotales del SQVI (doc_compr o material vacíos).
  const _t4000Map = new Map();
  if (esCD1003) traslados4000Raw.forEach(r => {
    const dc = String(r.doc_compr ?? '').trim();
    const pos = String(r.pos ?? '').trim();
    if (!dc || !String(r.material ?? '').trim()) return; // excluir subtotales
    const k = `${dc}|${pos}`;
    const existing = _t4000Map.get(k);
    // Preferir la fila con fecha válida (no 00.00.0000 ni vacía)
    const esValida = fe => fe && String(fe).trim() !== '' && String(fe).trim() !== '00.00.0000';
    if (!existing || (!esValida(existing.fe_entrega) && esValida(r.fe_entrega))) {
      _t4000Map.set(k, r);
    }
  });
  const t4000 = Array.from(_t4000Map.values());

  const destinosOrigen = (CALENDARIOS[planOrigen] && CALENDARIOS[planOrigen].destinos) || CENTROS_QUIEBRES;
  const centrosSet = new Set(destinosOrigen);
  const mananaTemp = new Date(); mananaTemp.setDate(mananaTemp.getDate() + 1);
  const centrosProgramados = getCentrosProgramados(
    calendarioRows.filter(r => String(r.centro ?? '').trim() === planOrigen),
    mananaTemp.getDay());

  // El CD 1003 despacha el sábado: si hoy es viernes, la planificación cubre el
  // sábado (mañana) y también el lunes siguiente. Se amplían 2 días las ventanas
  // hacia adelante para saltar el fin de semana e incluir el lunes.
  const esViernes = new Date().getDay() === 5;
  const diasExtraFinde = esViernes ? 2 : 0;

  const resultado = Array.from(centrosSet).map(ce => {
    // Capacidad de referencia (camión lleno) para los umbrales de camión
    // cliente (80%) y fábrica (85%). La capacidad efectiva del CD se calcula
    // más abajo (La Calera/San Bernardo usan 15 T si no alcanzan a llenar 28 T).
    const capRef = CAP_CAMION_DEFAULT;
    const quiebresMat = quiebresByCentro[ce] || new Set();
    const det = { quiebre: [], stock: [], revex: [], cross: [], ventaCons: [], retiro: [], cliente: [], fabSuc: [], fabCli: [] };
    const itemT = (r, t) => ({ pt: r.doc_compr, material: r.material, nombre: r.texto_breve, fecha: r.fecha_confirmada, ctd: r.ctd_confirmada, ton: t, pv: r.documento });

    // 1. Traslados Quiebre  (excluye líneas con ctd_confirmada = 0 → ya entregadas)
    const tonQuiebre = traslados
      .filter(r => String(r.ce ?? '').trim() === ce)
      .filter(r => quiebresMat.has(String(r.material ?? '').trim()))
      .filter(r => fechaEnRango(r.fecha_confirmada, 10, 7))
      .filter(r => parseNum(r.ctd_confirmada) > 0)
      .reduce((sum, r) => { const t = calcTon(maxPesoDim(r.peso_neto, r.tamano_dimens), r.ctd_confirmada); det.quiebre.push(itemT(r, t)); return sum + t; }, 0);

    // 2. Traslados Stock / Abastecimiento  (ídem)
    const tonStock = traslados
      .filter(r => String(r.ce ?? '').trim() === ce)
      .filter(r => !quiebresMat.has(String(r.material ?? '').trim()))
      .filter(r => fechaEnRango(r.fecha_confirmada, 10, 7))
      .filter(r => parseNum(r.ctd_confirmada) > 0)
      .reduce((sum, r) => { const t = calcTon(maxPesoDim(r.peso_neto, r.tamano_dimens), r.ctd_confirmada); det.stock.push(itemT(r, t)); return sum + t; }, 0);

    // 3. REVEX (peso_neto_2 × ctd_pedido — igual que la vista REVEX)
    const tonRevex = revex
      .filter(r => String(r.ce ?? '').trim() === ce)
      .reduce((sum, r) => { const t = calcTon(parseNum(r.peso_neto_2), r.ctd_pedido); det.revex.push(itemT(r, t)); return sum + t; }, 0);

    // 4. Crossdocking 4000 — SÓLO pendientes (ctd_pedido > procesado). Fecha -3/+3.
    //    "Procesado" = MAX(ctd_entregada, cantidad_salida) para cubrir los tres casos:
    //      · ctd_entregada == cantidad_salida > 0  → entregado, excluir
    //      · cantidad_salida > ctd_entregada        → en tránsito; pend = ctd_pedido - cantidad_salida
    //      · cantidad_salida == 0                   → no ha salido; pend = ctd_pedido - ctd_entregada
    //    Anomalía SAP (ctd_entregada > cantidad_salida con salida=0): MAX deja pend=0 → excluido.
    //    La vista muestra todos los pendientes; el plan aplica ventana -3/+3 días.
    const tonCross = t4000
      .filter(r => String(r.ce ?? '').trim() === ce)
      .filter(r => fechaEnRango(r.fe_entrega, 3, 3))
      .filter(r => parseNum(r.ctd_pedido) > Math.max(parseNum(r.ctd_entregada), parseNum(r.cantidad_salida)))
      .reduce((sum, r) => { const pend = parseNum(r.ctd_pedido) - Math.max(parseNum(r.ctd_entregada), parseNum(r.cantidad_salida)); const t = calcTon(maxPesoDim(r.peso_neto, r.tamano_dimens), pend);
        det.cross.push({ pt: r.doc_compr, origen: String(r.cesu ?? '').trim(), ceDestino: String(r.ce ?? '').trim(), almDestino: String(r.alm ?? '').trim(), material: r.material, nombre: r.texto_breve, fecha: r.fe_entrega, ctdPend: pend, ton: t, pv: r.documento }); return sum + t; }, 0);

    // 5. Notas de Venta 1003 (ofvta = centro): requiere ruta, excluye RETIRA.
    //    >26T  ⇒ CAMIÓN CLIENTE (directo al cliente, no se consolida). Fecha -3/+3.
    //    ≤26T  ⇒ PEDIDO DE VENTA DIRECTA (consolida con la carga del CD).   Fecha -3/+3.
    //    Dedup doc_ventas|material: el SQVI puede tener varias líneas para el mismo
    //    PV+material (distintas fechas). Se conserva la fila con fecha más reciente,
    //    igual que la lógica usada en la vista tabla de pedidos de ventas.
    const _ventasDedupMap = new Map();
    ventas
      .filter(r => String(r.ofvta ?? '').trim() === ce)
      .filter(r => String(r.ruta ?? '').trim() !== '')
      .filter(r => normTxt(r.ruta).indexOf('RETIRA') === -1)
      .filter(r => fechaEnRango(r.fe_entrega, 3, 3))
      .forEach(r => {
        const k = `${String(r.doc_ventas ?? '').trim()}|${String(r.material ?? '').trim()}`;
        const ex = _ventasDedupMap.get(k);
        if (!ex) { _ventasDedupMap.set(k, r); return; }
        const dNew = parseDateSAP(r.fe_entrega), dOld = parseDateSAP(ex.fe_entrega);
        if (dNew && (!dOld || dNew >= dOld)) _ventasDedupMap.set(k, r);
      });
    const ventasCe = Array.from(_ventasDedupMap.values());
    const ventasPorDoc = {};
    ventasCe.forEach(r => { const d = String(r.doc_ventas ?? '').trim(); (ventasPorDoc[d] = ventasPorDoc[d] || []).push(r); });
    let tonVentaCliente = 0, tonVentaCons = 0;
    for (const [doc, items] of Object.entries(ventasPorDoc)) {
      const lineItems = []; let tonDoc = 0;
      items.forEach(r => {
        const pend = parseNum(r.ctd_confirmada) - parseNum(r.cantidad_entrg);
        if (pend <= 0) return;
        const t = calcTon(maxPesoDim(r.peso_neto, r.tamano_dimens), pend);
        tonDoc += t;
        const rl = lookupRuta(r.ruta);
        lineItems.push({ pv: doc, material: r.material, nombre: r.denominacion_de_posicion, cant: pend, ruta: r.ruta, comuna: rl.comuna, region: rl.region, fecha: r.fe_entrega, ton: t });
      });
      if (tonDoc <= 0) continue;
      if (tonDoc > 26) { tonVentaCliente += tonDoc; det.cliente.push(...lineItems); }
      else { tonVentaCons += tonDoc; det.ventaCons.push(...lineItems); }
    }

    // 6. Retiros proveedor CONSOLIDAR CD (tipo_retiro=FAB-CD) → parte del CD.
    const retirosCons = retiros
      .filter(r => String(r.ce ?? '').trim() === ce)
      .filter(r => (estadosRetiro[String(r.doc_compr ?? '').trim()] || {}).tipo_retiro === 'FAB-CD');
    const itemR = (r, cant, t) => { const _oc = String(r.doc_compr ?? '').trim(); const ee = (estadosRetiro[_oc] || {}).entrega_entrante || ''; return { oc: r.doc_compr, idProv: r.proveedor, prov: r.nombre_1, material: r.material, nombre: r.texto_breve, fecha: r.fe_entrega, cant, ton: t, pv: r.documento, entrega_entrante: ee }; };
    const tonRetiro = retirosCons.reduce((sum, r) => {
      const cant = parseNum(r.ctd_pedido) - parseNum(r.ctd_entregada);
      const t = calcTon(maxPesoDim(r.peso_bruto, r.tamano_dimens), cant);
      det.retiro.push(itemR(r, cant, t)); return sum + t;
    }, 0);

    // 6b. Retiros FÁBRICA (alm ≠ 4000, pendientes):
    //   - CAMIÓN FÁBRICA-CLIENTE: una OC asociada a pedido de venta cuyo total ≥85% cap.
    //   - CAMIÓN FÁBRICA-SUCURSAL: OC(s) del mismo proveedor (sin PV) cuyo total ≥85% cap.
    const retirosFab = retiros
      .filter(r => String(r.ce ?? '').trim() === ce)
      .filter(r => (estadosRetiro[String(r.doc_compr ?? '').trim()] || {}).tipo_retiro !== 'FAB-CD')
      .filter(r => (parseNum(r.ctd_pedido) - parseNum(r.ctd_entregada)) > 0);
    const ocCli = {}, provSuc = {};   // oc/proveedor -> { ton, items:[] }
    retirosFab.forEach(r => {
      const cant = parseNum(r.ctd_pedido) - parseNum(r.ctd_entregada);
      const t = calcTon(maxPesoDim(r.peso_bruto, r.tamano_dimens), cant);
      const item = itemR(r, cant, t);
      if (String(r.documento ?? '').trim() !== '') {
        const oc = String(r.doc_compr ?? '').trim();
        (ocCli[oc] = ocCli[oc] || { ton: 0, items: [] }); ocCli[oc].ton += t; ocCli[oc].items.push(item);
      } else {
        const p = String(r.proveedor ?? '').trim();
        (provSuc[p] = provSuc[p] || { ton: 0, items: [] }); provSuc[p].ton += t; provSuc[p].items.push(item);
      }
    });
    let tonFabCli = 0, tonFabSuc = 0;
    Object.values(ocCli).forEach(b => { tonFabCli += b.ton; det.fabCli.push(...b.items); });
    Object.values(provSuc).forEach(b => { tonFabSuc += b.ton; det.fabSuc.push(...b.items); });

    // Total del CAMIÓN CD (consolidado). Orden de prioridad con que se llena el
    // camión: REVEX → Venta 1003 consolidable → Retiro CD → Crossdocking →
    // Traslados Quiebre → Traslados Abastecimiento.
    const total = tonRevex + tonVentaCons + tonRetiro + tonCross + tonQuiebre + tonStock;

    // Capacidad efectiva del CD. La Calera (1050) y San Bernardo (1005) usan un
    // camión de 15 T si en el corte no alcanzan a llenar uno de 28 T.
    let cap = CAP_CAMION_DEFAULT;
    if (CENTROS_CAMION_REDUCIDO.includes(ce)) cap = total >= CAP_CAMION_DEFAULT ? CAP_CAMION_DEFAULT : CAP_CAMION_REDUCIDO;

    const pct = cap > 0 ? Math.round(total / cap * 100) : 0;
    const sobrecarga = Math.max(0, total - cap);
    // FALTA/SOBRA: positivo (rojo) = falta carga, negativo mostrado en verde = sobra.
    const faltan = Math.max(0, cap - total);
    const enCalendario = centrosProgramados.has(ce);

    let status, statusCls;
    if (pct >= 80) { status = 'PROGRAMAR'; statusCls = 'bg-green-700 text-white'; }
    else if (pct >= 70) { status = 'REVISAR'; statusCls = 'bg-yellow-600 text-white'; }
    else { status = 'CARGA INSUFICIENTE'; statusCls = 'bg-gray-400 text-white'; }

    let obs = '';
    if (!enCalendario && pct >= 70) obs = 'CUPO EXTRA';
    if (enCalendario && pct < 70) obs = 'EN CALENDARIO - CARGA BAJA';
    if (sobrecarga > 0) obs = (obs ? obs + ' · ' : '') + '2º CAMIÓN (~' + fmtNum(sobrecarga, 1) + ' T)';

    return {
      ce, nombre: getNombreCentro(ce), cap,
      tonQuiebre, tonStock, tonRevex, tonCross, tonVentaCons, tonVentaCliente, tonRetiro, tonFabSuc, tonFabCli,
      total, faltan, sobrecarga, pct, status, statusCls, obs, enCalendario,
      camionCliente: tonVentaCliente > 0, camionFabSuc: tonFabSuc > 0, camionFabCli: tonFabCli > 0,
      det,
    };
  }).sort((a, b) => {
    // (AJUSTE 3.0) Prioridad del día primero, luego % completitud
    if (a.enCalendario !== b.enCalendario) return a.enCalendario ? -1 : 1;
    return b.pct - a.pct;
  });

  const manana = new Date(); manana.setDate(manana.getDate() + 1);
  const diasSemana = ['Domingo','Lunes','Martes','Miércoles','Jueves','Viernes','Sábado'];
  const fechaLabel = `${diasSemana[manana.getDay()]}, ${manana.toLocaleDateString('es-CL', { day: 'numeric', month: 'long', year: 'numeric' })}`
    + (esViernes ? ' (incluye lunes próximo — despacho CD 1003 del sábado)' : '');

  function truckSVG(pct) {
    const p = Math.min(pct, 100);
    const fill = pct >= 80 ? '#15803d' : pct >= 70 ? '#ca8a04' : '#9ca3af';
    const bgFill = '#e5e7eb';
    return `<svg viewBox="0 0 60 30" width="64" height="32" xmlns="http://www.w3.org/2000/svg">
      <rect x="0" y="4" width="38" height="20" rx="2" fill="${bgFill}" stroke="#6b7280" stroke-width="1"/>
      <rect x="0" y="${4 + 20 * (1 - p/100)}" width="38" height="${20 * p/100}" rx="0" fill="${fill}" opacity="0.85"/>
      <path d="M38 10 h8 l8 8 v6 h-16 z" fill="${bgFill}" stroke="#6b7280" stroke-width="1"/>
      <circle cx="10" cy="27" r="3" fill="#374151"/><circle cx="28" cy="27" r="3" fill="#374151"/><circle cx="50" cy="27" r="3" fill="#374151"/>
    </svg>`;
  }
  const iconCamion = (cls) => `<span class="material-symbols-outlined text-[22px] ${cls}">local_shipping</span>`;

  const NCOLS = 16; // columnas de la tabla (para el colspan del detalle)

  // Tabla genérica de detalle. alignRight = Set de índices de columnas numéricas.
  function tablaDet(headers, filas, alignRight) {
    const head = headers.map((h, i) => `<th class="pr-md text-[10px] uppercase text-secondary ${alignRight.has(i) ? 'text-right' : 'text-left'}">${escapeHtml(h)}</th>`).join('');
    const body = filas.length
      ? filas.map(fila => `<tr class="border-b border-outline-variant/40">${fila.map((v, i) => `<td class="py-[2px] pr-md text-[12px] ${alignRight.has(i) ? 'text-right num-clear' : ''}">${escapeHtml(String(v ?? ''))}</td>`).join('')}</tr>`).join('')
      : `<tr><td colspan="${headers.length}" class="text-secondary text-[12px] py-xs">Sin ítems.</td></tr>`;
    return `<table class="w-full text-[12px] mb-xs"><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table>`;
  }
  function blkWrap(lbl, items, tableHtml) {
    const sub = items.reduce((s, d) => s + (d.ton || 0), 0);
    return `<div class="mb-md">
      <div class="text-[12px] font-bold text-primary mb-xs">${escapeHtml(lbl)} <span class="text-secondary font-normal">(${fmtNum(sub, 4)} Ton)</span></div>
      ${tableHtml}</div>`;
  }
  const camMark = d => d._enCamion === undefined ? '' : (d._enCamion ? '✓ SÍ' : '✗ EXCEDE');
  const shiftSet = (s) => new Set([...s].map(i => i + 1));
  // Bloque Traslados (Quiebre / Abastecimiento / REVEX / Crossdocking)
  function blkTraslado(lbl, items, marcar) {
    if (!items.length) return '';
    let heads = ['Pedido de Traslado','ID Material','Nombre Material','Fecha de Entrega','Cantidad Confirmada','Ton SKU','Pedido de Venta'];
    let align = new Set([4, 5]);
    let filas = items.map(d => [d.pt, d.material, d.nombre, d.fecha, d.ctd, fmtNum(d.ton, 4), d.pv]);
    if (marcar) { heads = ['En Camión', ...heads]; align = shiftSet(align); filas = items.map((d, i) => [camMark(d), ...filas[i]]); }
    return blkWrap(lbl, items, tablaDet(heads, filas, align));
  }
  // Bloque Crossdocking (columnas completas, sin ocultar)
  function blkCrossdocking(lbl, items, marcar) {
    if (!items.length) return '';
    let heads = ['Origen','Pedido de Traslado','Centro Destino','Almacén Destino','Fecha de Entrega','ID Material','Nombre Material','Cant. Pendiente','Ton SKU','Pedido de Venta'];
    let align = new Set([7, 8]);
    let filas = items.map(d => [d.origen, d.pt, d.ceDestino, d.almDestino, d.fecha, d.material, d.nombre, fmtNum(d.ctdPend, 1), fmtNum(d.ton, 4), d.pv]);
    if (marcar) { heads = ['En Camión', ...heads]; align = shiftSet(align); filas = items.map((d, i) => [camMark(d), ...filas[i]]); }
    return blkWrap(lbl, items, tablaDet(heads, filas, align));
  }
 
  // Bloque Retiros de Fábrica
  function blkRetiro(lbl, items, marcar) {
    if (!items.length) return '';
    let heads = ['Orden de Compra','Entrega Entrante','Id Proveedor','Proveedor','ID Material','Nombre Material','Fecha de Retiro','Cantidad','Ton SKU','Pedido de Venta'];
    let align = new Set([7, 8]);
    let filas = items.map(d => [d.oc, d.entrega_entrante || '', d.idProv, d.prov, d.material, d.nombre, d.fecha, fmtNum(parseNum(d.cant), 1), fmtNum(d.ton, 4), d.pv]);
    if (marcar) { heads = ['En Camión', ...heads]; align = shiftSet(align); filas = items.map((d, i) => [camMark(d), ...filas[i]]); }
    return blkWrap(lbl, items, tablaDet(heads, filas, align));
  }
  // Bloque Pedidos de Venta
  function blkVenta(lbl, items, marcar) {
    if (!items.length) return '';
    let heads = ['Pedido de Venta','ID Material','Nombre Material','Cantidad','Id Ruta','Comuna','Región','Fecha de Entrega','Ton SKU'];
    let align = new Set([3, 8]);
    let filas = items.map(d => [d.pv, d.material, d.nombre, fmtNum(parseNum(d.cant), 1), d.ruta, d.comuna, d.region, d.fecha, fmtNum(d.ton, 4)]);
    if (marcar) { heads = ['En Camión', ...heads]; align = shiftSet(align); filas = items.map((d, i) => [camMark(d), ...filas[i]]); }
    return blkWrap(lbl, items, tablaDet(heads, filas, align));
  }

  // Marca, en orden de prioridad, qué ítems entran en el camión CD según su
  // capacidad efectiva (r.cap). Devuelve totales cargado/excede.
  function marcarCapacidadCD(r) {
    const orden = [r.det.revex, r.det.ventaCons, r.det.retiro, r.det.cross, r.det.quiebre, r.det.stock];
    let acc = 0;
    orden.forEach(arr => (arr || []).forEach(d => {
      if (acc + d.ton <= r.cap + 1e-9) { d._enCamion = true; acc += d.ton; }
      else { d._enCamion = false; }
    }));
    return { cargado: acc, excede: Math.max(0, (r.total || 0) - acc) };
  }

  const TRUCK_TITULOS = {
    cd: 'Camión CD (consolidado)',
    cliente: 'Camión Cliente (pedido de venta ≥80%)',
    fabSuc: 'Camión Fábrica-Sucursal (OC ≥85% sin pedido de venta)',
    fabCli: 'Camión Fábrica-Cliente (OC ≥85% con pedido de venta)',
  };

  function detalleRow(r, tipo) {
    let blocks = '', banner = '', excedeBlocks = '';
    if (tipo === 'cd') {
      const fill = marcarCapacidadCD(r);
      const cats = ['revex','ventaCons','retiro','cross','quiebre','stock'];
      const inC = {}, outC = {};
      cats.forEach(k => { inC[k] = (r.det[k]||[]).filter(d => d._enCamion); outC[k] = (r.det[k]||[]).filter(d => !d._enCamion); });
      banner = `<div class="mb-sm px-md py-sm rounded-lg bg-blue-50 border border-blue-200 text-[12px] text-blue-900 inline-flex flex-wrap items-center gap-md">
        <span><strong>Capacidad camión:</strong> ${fmtNum(r.cap, 0)} t</span>
        <span><strong>Cargado:</strong> ${fmtNum(fill.cargado, 1)} t</span>
        ${fill.excede > 0 ? `<span class="text-green-700 font-bold"><strong>Sobra:</strong> +${fmtNum(fill.excede, 1)} t (requiere 2º camión)</span>` : '<span class="text-green-700 font-bold">✓ Todo cabe en el camión</span>'}
      </div>`;
      blocks =
        blkTraslado('1º Pedidos de Traslados REVEX', inC.revex) +
        blkVenta('2º Pedidos de Venta Directa Consolidados', inC.ventaCons) +
        blkRetiro('3º Retiros de Proveedor Consolidados (CD)', inC.retiro) +
        blkCrossdocking('4º Pedidos de Traslados Crossdocking', inC.cross) +
        blkTraslado('5º Pedidos de Traslados Quiebre', inC.quiebre) +
        blkTraslado('6º Pedidos de Traslados Abastecimiento', inC.stock);
      // No se muestra sección de excedentes: el detalle incluye solo lo que entra en el camión.
    }
    else if (tipo === 'cliente') blocks = blkVenta('Pedidos de Venta directos al cliente', r.det.cliente);
    else if (tipo === 'fabSuc') blocks = blkRetiro('Órdenes de Compra Fábrica-Sucursal', r.det.fabSuc);
    else if (tipo === 'fabCli') blocks = blkRetiro('Órdenes de Compra Fábrica-Cliente', r.det.fabCli);
    return `<tr class="bg-surface-container-low"><td colspan="${NCOLS}" class="p-md">
      <div class="border border-outline-variant rounded-lg p-md bg-surface-container-lowest">
        <div class="flex items-center justify-between mb-sm">
          <h4 class="font-bold text-on-surface text-[13px]">${escapeHtml(TRUCK_TITULOS[tipo] || '')} — ${escapeHtml(r.nombre)} (${r.ce})</h4>
          <button data-descarga="${r.ce}|${tipo}" class="bg-surface-container-high text-on-surface px-sm py-xs rounded-lg text-[12px] font-bold hover:bg-surface-container-highest inline-flex items-center gap-xs">
            <span class="material-symbols-outlined text-[15px]">download</span>Descargar detalle</button>
        </div>
        ${banner}
        ${blocks || '<p class="text-secondary text-[12px]">Sin ítems.</p>'}
        ${excedeBlocks}
      </div></td></tr>`;
  }

  // Genera el CSV del detalle de un camión (para el botón de descarga).
  function csvDetalleCamion(r, tipo) {
    const cats = tipo === 'cd'
      ? [['REVEX', r.det.revex, 'T'], ['Venta Consolidada', r.det.ventaCons, 'V'], ['Retiro CD', r.det.retiro, 'R'],
         ['Crossdocking', r.det.cross, 'T'], ['Quiebre', r.det.quiebre, 'T'], ['Abastecimiento', r.det.stock, 'T']]
      : tipo === 'cliente' ? [['Venta Cliente', r.det.cliente, 'V']]
      : tipo === 'fabSuc'  ? [['Fábrica-Sucursal', r.det.fabSuc, 'R']]
      :                      [['Fábrica-Cliente', r.det.fabCli, 'R']];
    const headers = ['Categoría','Documento','Id Proveedor','Proveedor','Id Material','Nombre Material','Ruta','Comuna','Región','Fecha','Cantidad','Ton SKU'];
    const filas = [];
    cats.forEach(([cat, items, t]) => (items || []).filter(d => tipo !== 'cd' || d._enCamion).forEach(d => {
      if (t === 'T') filas.push([cat, d.pt, '', '', d.material, d.nombre, '', '', '', d.fecha || '', d.ctd || '', fmtNum(d.ton, 4)]);
      else if (t === 'R') filas.push([cat, d.oc, d.idProv, d.prov, d.material, d.nombre, '', '', '', d.fecha || '', fmtNum(parseNum(d.cant), 1), fmtNum(d.ton, 4)]);
      else filas.push([cat, d.pv, '', '', d.material, d.nombre, d.ruta, d.comuna, d.region, d.fecha || '', fmtNum(parseNum(d.cant), 1), fmtNum(d.ton, 4)]);
    }));
    const esc = v => { v = v == null ? '' : String(v); return /[;"\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; };
    const lines = [headers.join(';')].concat(filas.map(f => f.map(esc).join(';')));
    const blob = new Blob(['﻿' + lines.join('\n')], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `PlanCarga_${r.ce}_${tipo}.csv`;
    document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
  }

  // Celda de camión clicable con drill-down.
  function truckCell(r, tipo, activo, contenido) {
    if (!activo) return '<td class="py-sm pr-md text-center"><span class="text-secondary">—</span></td>';
    const abierto = planDetalleAbierto.has(r.ce + '|' + tipo);
    return `<td class="py-sm pr-md text-center">
      <button data-truck="${r.ce}|${tipo}" title="Ver contenido del camión" class="inline-flex flex-col items-center cursor-pointer hover:opacity-80">
        ${contenido}
        <span class="text-[9px] text-primary font-bold">${abierto ? 'ocultar' : 'ver'}</span>
      </button></td>`;
  }

  const act = quiebresRaw.length ? horaChile(quiebresRaw[0].cargado_en) : '';

  function draw() {
    stage.innerHTML = `
    <div class="bg-surface-container-lowest border border-outline-variant p-lg shadow-sm rounded-lg">
      <div class="flex flex-wrap items-end justify-between gap-md mb-md border-b border-outline-variant pb-sm">
        <div>
          <h3 class="text-headline-sm font-bold text-on-surface">GESTIÓN TRONCALES – PLAN DE CARGA</h3>
          <p class="text-[13px] text-secondary">Planificación: <strong>${escapeHtml(fechaLabel)}</strong>${act ? ' · datos actualizados ' + escapeHtml(act) : ''}</p>
        </div>
        <div class="flex items-center gap-sm">
          <span class="text-[11px] text-secondary font-bold uppercase">Centro Origen:</span>
          ${Object.keys(CALENDARIOS).map(id => `
            <button data-origen="${id}" class="px-md py-sm rounded-lg text-[13px] font-bold transition-colors
              ${planOrigen === id ? 'bg-primary text-white' : 'bg-surface-container-high text-on-surface hover:bg-surface-container-highest'}">
              <span class="material-symbols-outlined text-[16px] align-middle mr-xs">warehouse</span>${escapeHtml(CALENDARIOS[id].nombre)} (${id})
            </button>`).join('')}
          <button data-refrescar title="Refrescar" class="bg-surface-container-high text-on-surface px-md py-sm rounded-lg text-[13px] font-bold hover:bg-surface-container-highest">
            <span class="material-symbols-outlined text-[16px] align-middle">refresh</span></button>
        </div>
      </div>

      <div class="overflow-x-auto">
        <table class="w-full text-[13px]">
          <thead class="sticky top-0 bg-surface-container-lowest z-10">
            <tr class="text-left text-[11px] uppercase tracking-wide text-secondary border-b-2 border-primary/30">
              <th class="py-sm pr-md font-bold whitespace-nowrap">Sucursal</th>
              <th class="py-sm pr-md text-right font-bold whitespace-nowrap">1º REVEX</th>
              <th class="py-sm pr-md text-right font-bold whitespace-nowrap">2º Ped. Venta Directa</th>
              <th class="py-sm pr-md text-right font-bold whitespace-nowrap">3º Retiro Proveedor</th>
              <th class="py-sm pr-md text-right font-bold whitespace-nowrap">4º Ped. Traslados CrossDock</th>
              <th class="py-sm pr-md text-right font-bold whitespace-nowrap">5º Ped. Traslados Quiebres</th>
              <th class="py-sm pr-md text-right font-bold whitespace-nowrap">6º Ped. Traslados Abastecimiento</th>
              <th class="py-sm pr-md text-right font-bold whitespace-nowrap">Total CD</th>
              <th class="py-sm pr-md text-right font-bold whitespace-nowrap">FALTA / SOBRA</th>
              <th class="py-sm pr-md text-right font-bold whitespace-nowrap">% Compl.</th>
              <th class="py-sm pr-md text-center font-bold whitespace-nowrap">Camión CD</th>
              <th class="py-sm pr-md text-center font-bold whitespace-nowrap">Status</th>
              <th class="py-sm pr-md text-center font-bold whitespace-nowrap">Camión Cliente</th>
              <th class="py-sm pr-md text-center font-bold whitespace-nowrap">Camión Fáb-Sucursal</th>
              <th class="py-sm pr-md text-center font-bold whitespace-nowrap">Camión Fáb-Cliente</th>
              <th class="py-sm pr-md font-bold whitespace-nowrap">Observaciones</th>
            </tr>
          </thead>
          <tbody>
            ${resultado.map(r => {
              const rowBg = r.enCalendario ? 'bg-blue-50 border-l-4 border-l-primary' : 'bg-gray-50/60 opacity-90';
              const totalCls = r.pct >= 80 ? 'text-green-700' : r.pct >= 70 ? 'text-yellow-700' : 'text-red-600';
              const camCD = r.total > 0 ? truckSVG(r.pct) : '<span class="text-secondary text-[11px]">—</span>';
              const abiertos = ['cd','cliente','fabSuc','fabCli'].filter(tp => planDetalleAbierto.has(r.ce + '|' + tp));
              return `<tr class="border-b border-outline-variant/50 hover:bg-surface-container-low ${rowBg}">
                <td class="py-sm pr-md font-bold whitespace-nowrap">
                  ${r.enCalendario ? '<span class="inline-flex items-center gap-xs"><span class="material-symbols-outlined text-[16px] text-primary">calendar_today</span><span class="text-[9px] font-bold text-primary bg-primary/10 px-xs rounded">PRIORITARIO</span></span> ' : ''}
                  ${escapeHtml(r.nombre)}
                </td>
                <td class="py-sm pr-md text-right num-clear">${fmtNum(r.tonRevex, 1)}</td>
                <td class="py-sm pr-md text-right num-clear">${fmtNum(r.tonVentaCons, 1)}</td>
                <td class="py-sm pr-md text-right num-clear">${fmtNum(r.tonRetiro, 1)}</td>
                <td class="py-sm pr-md text-right num-clear">${fmtNum(r.tonCross, 1)}</td>
                <td class="py-sm pr-md text-right num-clear">${fmtNum(r.tonQuiebre, 1)}</td>
                <td class="py-sm pr-md text-right num-clear">${fmtNum(r.tonStock, 1)}</td>
                <td class="py-sm pr-md text-right num-clear font-bold ${totalCls}">${fmtNum(r.total, 1)}</td>
                <td class="py-sm pr-md text-right num-clear ${r.sobrecarga > 0 ? 'text-green-700 font-bold' : r.faltan > 0 ? 'text-red-600 font-bold' : ''}">${r.sobrecarga > 0 ? '+' + fmtNum(r.sobrecarga, 1) : fmtNum(r.faltan, 1)}</td>
                <td class="py-sm pr-md text-right num-clear font-bold">${r.pct}%</td>
                ${truckCell(r, 'cd', r.total > 0, camCD)}
                <td class="py-sm pr-md text-center"><span class="px-sm py-xs rounded text-[11px] font-bold ${r.statusCls}">${escapeHtml(r.status)}</span></td>
                ${truckCell(r, 'cliente', r.camionCliente, iconCamion('text-green-700') + '<div class="text-[9px] font-bold text-green-700">' + fmtNum(r.tonVentaCliente,1) + ' t</div>')}
                ${truckCell(r, 'fabSuc', r.camionFabSuc, iconCamion('text-blue-700') + '<div class="text-[9px] font-bold text-blue-700">' + fmtNum(r.tonFabSuc,1) + ' t</div>')}
                ${truckCell(r, 'fabCli', r.camionFabCli, iconCamion('text-purple-700') + '<div class="text-[9px] font-bold text-purple-700">' + fmtNum(r.tonFabCli,1) + ' t</div>')}
                <td class="py-sm pr-md text-[12px] ${r.obs.includes('EXTRA') ? 'text-blue-700 font-bold' : r.obs.includes('BAJA') ? 'text-orange-600 font-bold' : 'text-secondary'}">${escapeHtml(r.obs)}</td>
              </tr>
              ${abiertos.map(tp => detalleRow(r, tp)).join('')}`; }).join('')}
          </tbody>
        </table>
      </div>

      <div class="mt-md pt-sm border-t border-outline-variant flex flex-wrap gap-lg text-[12px] text-secondary items-center">
        <span class="inline-flex items-center gap-xs"><span class="material-symbols-outlined text-[14px] align-middle text-primary">calendar_today</span> PRIORITARIO = Centro en calendario de mañana</span>
        <span class="inline-flex items-center gap-xs">${iconCamion('text-green-700 text-[16px]')} Camión Cliente (venta ≥80%)</span>
        <span class="inline-flex items-center gap-xs">${iconCamion('text-blue-700 text-[16px]')} Camión Fábrica-Sucursal (OC ≥85% sin PV)</span>
        <span class="inline-flex items-center gap-xs">${iconCamion('text-purple-700 text-[16px]')} Camión Fábrica-Cliente (OC ≥85% con PV)</span>
        <span>Pincha cualquier camión para ver su contenido · Camión CD 1 por sucursal · Capacidad 28 T (15 T Calera/San Bernardo) · FALTA en rojo, SOBRA en verde</span>
      </div>
    </div>`;

    stage.querySelector('[data-refrescar]')?.addEventListener('click', () => { clearRawCache(); renderPlanCarga(stage); });
    stage.querySelectorAll('[data-origen]').forEach(btn => btn.addEventListener('click', () => {
      planOrigen = btn.dataset.origen; planDetalleAbierto.clear(); renderPlanCarga(stage);
    }));
    stage.querySelectorAll('[data-truck]').forEach(btn => btn.addEventListener('click', () => {
      const k = btn.dataset.truck;
      if (planDetalleAbierto.has(k)) planDetalleAbierto.delete(k); else planDetalleAbierto.add(k);
      draw();
    }));
    stage.querySelectorAll('[data-descarga]').forEach(btn => btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const [ce, tipo] = btn.dataset.descarga.split('|');
      const r = resultado.find(x => x.ce === ce);
      if (r) csvDetalleCamion(r, tipo);
    }));
  }

  draw();
}

// ============================================================================
// RENDER GENÉRICO DE VISTAS (chips, filtros, buscador, badges, drill-down,
// editable, modos, CSV)
// ============================================================================
async function renderVistaTabla(stage, cfg, modeIdx = 0) {
  // Config activa (soporta modos: STOCK / PEDIDO DE VENTAS)
  const active = cfg.modes
    ? Object.assign({}, cfg, cfg.modes[modeIdx])
    : cfg;

  stage.innerHTML = `<div class="text-secondary text-body-md p-md">Cargando ${escapeHtml(cfg.titulo)}…</div>`;
  const ctx = active.preload ? await active.preload() : {};
  const rawRows = await fetchAllRows(active.vista);
  const rows = active.transform ? active.transform(rawRows, ctx) : rawRows;

  const chip = active.chipFilter;
  const chipValues = chip ? Array.from(new Set(rows.map(r => String(r[chip.campo] ?? '')).filter(v => v))).sort() : [];
  let chipSel = 'all';

  const extraChips = (active.extraChips || []).map(ec => ({
    ...ec,
    values: Array.from(new Set(rows.map(r => String(r[ec.campo] ?? '')).filter(v => v))).sort(),
    sel: 'all',
  }));

  const filtroTextos = {};
  (active.filtros || []).forEach(f => { filtroTextos[f.campo] = ''; });
  let texto = '';
  let rangoDesde = '', rangoHasta = '';   // filtro por rango de fecha (dateRange)
  const expanded = new Set();

  // ISO (yyyy-mm-dd de <input type=date>) → Date 00:00
  function isoToDate(s) {
    if (!s) return null;
    const m = String(s).match(/^(\d{4})-(\d{2})-(\d{2})$/);
    return m ? new Date(+m[1], +m[2] - 1, +m[3]) : null;
  }

  function aplica() {
    const q = texto.trim().toLowerCase();
    const dr = active.dateRange;
    const dDesde = dr ? isoToDate(rangoDesde) : null;
    const dHasta = dr ? isoToDate(rangoHasta) : null;
    return rows.filter(r => {
      if (chip && chipSel !== 'all' && String(r[chip.campo] ?? '') !== chipSel) return false;
      for (const ec of extraChips) {
        if (ec.sel !== 'all' && String(r[ec.campo] ?? '') !== ec.sel) return false;
      }
      for (const f of (active.filtros || [])) {
        const fv = filtroTextos[f.campo]?.trim().toLowerCase();
        if (fv && !String(r[f.campo] ?? '').toLowerCase().includes(fv)) return false;
      }
      if (dr && (dDesde || dHasta)) {
        const d = parseDateSAP(r[dr.campo]);
        if (!d) return false;
        if (dDesde && d < dDesde) return false;
        if (dHasta && d > dHasta) return false;
      }
      if (q && !active.columnas.some(c => String(r[c.key] ?? '').toLowerCase().includes(q))) return false;
      return true;
    });
  }

  const chipCls = (v) => 'vt-chip px-sm py-xs border rounded text-[11px] font-bold uppercase transition-colors cursor-pointer ' +
    (chipSel === v ? 'bg-primary text-white border-primary' : 'bg-white border-outline-variant text-on-surface hover:bg-surface-container-high');
  const chipCls2 = (ec, v) => 'vt-chip px-sm py-xs border rounded text-[11px] font-bold uppercase transition-colors cursor-pointer ' +
    (ec.sel === v ? 'bg-primary text-white border-primary' : 'bg-white border-outline-variant text-on-surface hover:bg-surface-container-high');

  function cellValue(r, c) {
    if (c.valueFn) return c.valueFn(r);
    return String(r[c.key] ?? '');
  }

  function renderCell(r, c) {
    const cls = c.clsFn ? c.clsFn(r) : (c.cls || '');
    // Editable (select persistente)
    if (c.editable && active.editable && active.editable.key === c.key) {
      const cur = r[c.key];
      const opts = active.editable.options.map(o => `<option value="${escapeHtml(o.v)}" ${o.v === cur ? 'selected' : ''}>${escapeHtml(o.l)}</option>`).join('');
      const estilo = cur === 'coordinado' ? 'text-green-700 font-bold border-green-400' : 'text-secondary border-outline-variant';
      return `<td class="py-xs pr-md whitespace-nowrap">
        <select data-edit="${escapeHtml(String(r[active.expand?.idKey] ?? r[c.key]))}" data-editgid="${escapeHtml(String(r[active.expand?.idKey] ?? ''))}"
          class="border rounded px-[6px] py-[3px] text-[12px] bg-surface-container-lowest outline-none ${estilo}">${opts}</select></td>`;
    }
    // Badge
    if (c.badge) {
      const bcls = c.badge(r);
      const v = cellValue(r, c);
      return `<td class="py-xs pr-md whitespace-nowrap">${v ? `<span class="px-sm py-[2px] rounded-full text-[11px] font-bold ${bcls}">${escapeHtml(v)}</span>` : ''}</td>`;
    }
    // Expandable (clickeable → drill-down)
    if (c.expandable && active.expand) {
      const id = String(r[active.expand.idKey] ?? '');
      const abierto = expanded.has(id);
      const v = escapeHtml(cellValue(r, c));
      return `<td class="py-xs pr-md whitespace-nowrap ${cls}">
        <button data-exp="${escapeHtml(id)}" class="inline-flex items-center gap-xs text-primary font-bold hover:underline cursor-pointer">
          <span class="material-symbols-outlined text-[15px]">${abierto ? 'expand_less' : 'expand_more'}</span>${v}</button></td>`;
    }
    if (c.rawHtml) {
      return `<td class="py-xs pr-md whitespace-nowrap ${cls}">${cellValue(r, c)}</td>`;
    }
    return `<td class="py-xs pr-md whitespace-nowrap ${cls}">${escapeHtml(cellValue(r, c))}</td>`;
  }

  function detailRow(r, ncols) {
    const ex = active.expand;
    const nnum = ex.numCols || 2;
    const data = ex.build(r) || [];
    const head = ex.headers.map(h => `<th class="py-xs pr-md text-left text-[10px] uppercase text-secondary">${escapeHtml(h)}</th>`).join('');
    const body = data.length
      ? data.map(fila => `<tr class="border-b border-outline-variant/40">${fila.map((v, i) => `<td class="py-[2px] pr-md text-[12px] ${i >= fila.length - nnum ? 'text-right num-clear' : ''}">${escapeHtml(String(v ?? ''))}</td>`).join('')}</tr>`).join('')
      : `<tr><td colspan="${ex.headers.length}" class="text-secondary text-[12px] py-xs">Sin detalle.</td></tr>`;
    return `<tr class="bg-surface-container-low"><td colspan="${ncols}" class="p-md">
      <div class="border border-outline-variant rounded-lg p-md bg-surface-container-lowest">
        <table class="w-full"><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table>
      </div></td></tr>`;
  }

  function draw() {
    let filt = aplica();
    if (active.postFilter) filt = active.postFilter(filt, chipSel, ctx);
    const MAX = 1500;
    const shown = filt.slice(0, MAX);
    const act = rawRows.length ? horaChile(rawRows[0].cargado_en) : '';
    const badgesHtml = active.badges ? active.badges(filt, chipSel) : '';
    const ncols = active.columnas.length;

    const modosHtml = cfg.modes ? `<div class="flex items-center gap-xs mb-md">
      <span class="text-[11px] text-secondary font-bold uppercase mr-xs">Ver:</span>
      ${cfg.modes.map((m, i) => `<button data-modo="${i}" class="px-md py-xs border rounded text-[12px] font-bold uppercase transition-colors cursor-pointer ${i === modeIdx ? 'bg-primary text-white border-primary' : 'bg-white border-outline-variant text-on-surface hover:bg-surface-container-high'}">${escapeHtml(m.label)}</button>`).join('')}
    </div>` : '';

    stage.innerHTML = `
      <div class="bg-surface-container-lowest border border-outline-variant p-lg shadow-sm rounded-lg">
        <div class="flex flex-wrap items-end justify-between gap-md mb-md border-b border-outline-variant pb-sm">
          <div>
            <h3 class="text-headline-sm font-bold text-on-surface">${escapeHtml(cfg.titulo)}</h3>
            <p class="text-[13px] text-secondary">${filt.length} registro(s)${act ? ' · actualizado ' + escapeHtml(act) : ''}</p>
          </div>
          <div class="flex items-center gap-sm">
            <button data-refrescar title="Refrescar" class="bg-surface-container-high text-on-surface px-md py-sm rounded-lg text-[13px] font-bold hover:bg-surface-container-highest">
              <span class="material-symbols-outlined text-[16px] align-middle">refresh</span></button>
            <button data-csv class="bg-surface-container-high text-on-surface px-md py-sm rounded-lg text-[13px] font-bold hover:bg-surface-container-highest">
              <span class="material-symbols-outlined text-[16px] align-middle mr-xs">download</span>CSV</button>
          </div>
        </div>

        ${modosHtml}
        ${badgesHtml ? `<div class="flex flex-wrap gap-sm mb-md">${badgesHtml}</div>` : ''}

        <div class="flex flex-wrap items-start gap-x-lg gap-y-sm mb-md">
          ${chip ? `<div class="flex items-center gap-xs flex-wrap">
            <span class="text-[11px] text-secondary font-bold uppercase mr-xs">${escapeHtml(chip.label)}:</span>
            <button class="${chipCls('all')}" data-chip="all">Todos</button>
            ${chipValues.map(v => `<button class="${chipCls(v)}" data-chip="${escapeHtml(v)}">${escapeHtml(v)} ${escapeHtml(getNombreCentro(v))}</button>`).join('')}
          </div>` : ''}
          ${extraChips.map((ec, idx) => ec.values.length ? `<div class="flex items-center gap-xs flex-wrap">
            <span class="text-[11px] text-secondary font-bold uppercase mr-xs">${escapeHtml(ec.label)}:</span>
            <button class="${chipCls2(ec, 'all')}" data-echip="${idx}" data-eval="all">Todos</button>
            ${ec.values.map(v => `<button class="${chipCls2(ec, v)}" data-echip="${idx}" data-eval="${escapeHtml(v)}">${escapeHtml(v)}</button>`).join('')}
          </div>` : '').join('')}
          ${(active.filtros || []).map(f => `
            <label class="block">
              <span class="text-[11px] uppercase tracking-wide text-secondary font-bold">${escapeHtml(f.label)}</span>
              <input data-filtro="${f.campo}" value="${escapeHtml(filtroTextos[f.campo] || '')}" placeholder="Buscar…"
                class="mt-xs block border border-outline-variant rounded-lg px-md py-sm text-body-md focus:border-primary outline-none w-48"/>
            </label>`).join('')}
          ${active.dateRange ? `<div class="flex items-end gap-sm">
            <label class="block">
              <span class="text-[11px] uppercase tracking-wide text-secondary font-bold inline-flex items-center gap-xs"><span class="material-symbols-outlined text-[15px]">calendar_month</span>${escapeHtml(active.dateRange.label)} — Desde</span>
              <input type="date" data-rango="desde" value="${escapeHtml(rangoDesde)}"
                class="mt-xs block border border-outline-variant rounded-lg px-md py-sm text-body-md focus:border-primary outline-none"/>
            </label>
            <label class="block">
              <span class="text-[11px] uppercase tracking-wide text-secondary font-bold">Hasta</span>
              <input type="date" data-rango="hasta" value="${escapeHtml(rangoHasta)}"
                class="mt-xs block border border-outline-variant rounded-lg px-md py-sm text-body-md focus:border-primary outline-none"/>
            </label>
            ${(rangoDesde || rangoHasta) ? `<button data-rango-clear class="mb-[2px] px-sm py-sm text-secondary hover:text-error text-[12px] font-bold" title="Limpiar rango"><span class="material-symbols-outlined text-[18px] align-middle">close</span></button>` : ''}
          </div>` : ''}
          ${active.noBuscar ? '' : `<label class="block">
            <span class="text-[11px] uppercase tracking-wide text-secondary font-bold">${escapeHtml(active.searchLabel || 'Buscar general')}</span>
            <input data-buscar value="${escapeHtml(texto)}" placeholder="texto…"
              class="mt-xs block border border-outline-variant rounded-lg px-md py-sm text-body-md focus:border-primary outline-none"/>
          </label>`}
          <span class="text-[12px] text-secondary ml-auto self-end">${filt.length} fila(s)</span>
        </div>

        <div class="overflow-x-auto max-h-[68vh] overflow-y-auto">
          <table class="w-full text-[13px]">
            <thead class="sticky top-0 bg-surface-container-lowest z-10">
              <tr class="text-left text-[11px] uppercase tracking-wide text-secondary border-b border-outline-variant">
                ${active.columnas.map(c => `<th class="py-sm pr-md whitespace-nowrap">${escapeHtml(c.label)}</th>`).join('')}
              </tr>
            </thead>
            <tbody>
              ${shown.length === 0 ? `<tr><td colspan="${ncols}" class="py-lg text-center text-secondary">Sin datos.</td></tr>` :
                shown.map(r => {
                  const rowCls = active.rowClsFn ? active.rowClsFn(r) : '';
                  const id = active.expand ? String(r[active.expand.idKey] ?? '') : '';
                  const abierto = active.expand && expanded.has(id);
                  return `<tr class="border-b border-outline-variant/50 hover:bg-surface-container-low ${rowCls}">
                    ${active.columnas.map(c => renderCell(r, c)).join('')}
                  </tr>${abierto ? detailRow(r, ncols) : ''}`;
                }).join('')}
            </tbody>
          </table>
        </div>
        ${filt.length > MAX ? `<p class="text-[12px] text-secondary mt-sm">Mostrando ${MAX} de ${filt.length}. Usa los filtros para acotar.</p>` : ''}
      </div>`;

    // Listeners
    stage.querySelectorAll('[data-modo]').forEach(btn => btn.addEventListener('click', () => renderVistaTabla(stage, cfg, parseInt(btn.dataset.modo))));
    stage.querySelectorAll('[data-chip]').forEach(btn => btn.addEventListener('click', () => { chipSel = btn.dataset.chip; draw(); }));
    stage.querySelectorAll('[data-echip]').forEach(btn => btn.addEventListener('click', () => { extraChips[parseInt(btn.dataset.echip)].sel = btn.dataset.eval; draw(); }));
    stage.querySelectorAll('[data-filtro]').forEach(inp => inp.addEventListener('input', e => {
      filtroTextos[inp.dataset.filtro] = e.target.value; draw();
      const el = stage.querySelector(`[data-filtro="${inp.dataset.filtro}"]`);
      if (el) { el.focus(); el.setSelectionRange(el.value.length, el.value.length); }
    }));
    const inp = stage.querySelector('[data-buscar]');
    if (inp) inp.addEventListener('input', e => {
      texto = e.target.value; draw();
      const i = stage.querySelector('[data-buscar]');
      if (i) { i.focus(); i.setSelectionRange(i.value.length, i.value.length); }
    });
    stage.querySelectorAll('[data-rango]').forEach(el => el.addEventListener('change', e => {
      if (el.dataset.rango === 'desde') rangoDesde = e.target.value; else rangoHasta = e.target.value;
      draw();
    }));
    stage.querySelector('[data-rango-clear]')?.addEventListener('click', () => { rangoDesde = ''; rangoHasta = ''; draw(); });
    stage.querySelectorAll('[data-exp]').forEach(btn => btn.addEventListener('click', () => {
      const id = btn.dataset.exp;
      if (expanded.has(id)) expanded.delete(id); else expanded.add(id);
      draw();
    }));
    stage.querySelectorAll('[data-edit]').forEach(sel => sel.addEventListener('change', async () => {
      const id = sel.dataset.editgid || sel.dataset.edit;
      const row = rows.find(r => String(r[active.expand?.idKey] ?? '') === String(id));
      if (row && active.editable) {
        const prevVal = row[active.editable.key];
        row[active.editable.key] = sel.value;
        const ok = await active.editable.onChange(row, sel.value, ctx);
        if (ok === false) { row[active.editable.key] = prevVal; }
        draw();
      }
    }));
    stage.querySelector('[data-refrescar]')?.addEventListener('click', () => { clearRawCache(); renderVistaTabla(stage, cfg, modeIdx); });
    stage.querySelector('[data-csv]')?.addEventListener('click', () => exportarCSV(active, filt));
  }

  draw();
}

function exportarCSV(cfg, filas) {
  const headers = cfg.columnas.map(c => c.label);
  const esc = v => { v = v == null ? '' : String(v); return /[;"\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; };
  const val = (r, c) => c.valueFn ? c.valueFn(r) : r[c.key];
  const lines = [headers.join(';')].concat(filas.map(r => cfg.columnas.map(c => esc(val(r, c))).join(';')));
  const blob = new Blob(['﻿' + lines.join('\n')], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = (cfg.titulo || 'export').replace(/[^\w]+/g, '_') + '.csv';
  document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
}

// ============================================================================
// SUBMENU 1: PROVEEDORES
// ============================================================================
async function loadProveedores() {
  const { data, error } = await supabase
    .from('abast_proveedores')
    .select('*, direcciones:abast_proveedor_direcciones(*)')
    .order('nombre', { ascending: true });
  if (error) { console.error(error); showAlert('Error al cargar proveedores: ' + error.message, 'error'); return []; }
  return data || [];
}

async function renderProveedores(stage) {
  stage.innerHTML = `<div class="text-secondary text-body-md p-md">Cargando proveedores…</div>`;
  proveedores = await loadProveedores();

  let filtro = '';

  function draw() {
    const q = filtro.trim().toLowerCase();
    const rows = proveedores.filter(p => !q
      || (p.nombre || '').toLowerCase().includes(q)
      || (p.id || '').toLowerCase().includes(q)
      || (p.contacto_nombre || '').toLowerCase().includes(q));

    stage.innerHTML = `
      <div class="bg-surface-container-lowest border border-outline-variant p-lg shadow-sm rounded-lg">
        <div class="flex items-center justify-between mb-md border-b border-outline-variant pb-sm">
          <div>
            <h3 class="text-headline-sm font-bold text-on-surface">GESTIÓN TRONCALES – PROVEEDORES</h3>
            <p class="text-[13px] text-secondary">Contactos y direcciones de fabrica para retiro de material</p>
          </div>
          <button id="ab-nuevo-prov"
            class="bg-primary text-on-primary px-md py-sm rounded-lg text-body-md font-bold hover:opacity-90 transition-opacity">
            <span class="material-symbols-outlined text-[18px] align-middle mr-xs">add</span>Nuevo Proveedor
          </button>
        </div>

        <div class="mb-md">
          <input id="ab-prov-buscar" value="${escapeHtml(filtro)}" placeholder="Buscar por ID, nombre o contacto…"
            class="w-full md:w-1/2 border border-outline-variant rounded-lg px-md py-sm text-body-md focus:border-primary outline-none" />
        </div>

        <div class="overflow-x-auto">
          <table class="w-full text-body-md">
            <thead>
              <tr class="text-left text-[12px] uppercase tracking-wide text-secondary border-b border-outline-variant">
                <th class="py-sm pr-md">ID</th>
                <th class="py-sm pr-md">Proveedor</th>
                <th class="py-sm pr-md">Contacto</th>
                <th class="py-sm pr-md">Correo</th>
                <th class="py-sm pr-md">Telefono</th>
                <th class="py-sm pr-md text-center">Fabricas</th>
                <th class="py-sm pr-md text-right">Acciones</th>
              </tr>
            </thead>
            <tbody>
              ${rows.length === 0 ? `
                <tr><td colspan="7" class="py-lg text-center text-secondary">Sin proveedores registrados.</td></tr>
              ` : rows.map(p => `
                <tr class="border-b border-outline-variant/60 hover:bg-surface-container-low">
                  <td class="py-sm pr-md font-data-mono text-[13px]">${escapeHtml(p.id)}</td>
                  <td class="py-sm pr-md font-semibold">${escapeHtml(p.nombre || '')}
                    ${p.activo === false ? '<span class="ml-xs text-[11px] text-error">(inactivo)</span>' : ''}</td>
                  <td class="py-sm pr-md">${escapeHtml(p.contacto_nombre || '—')}</td>
                  <td class="py-sm pr-md">${escapeHtml(p.contacto_correo || '—')}</td>
                  <td class="py-sm pr-md">${escapeHtml(p.contacto_telefono || '—')}</td>
                  <td class="py-sm pr-md text-center">
                    <span class="inline-flex items-center justify-center min-w-[24px] h-[24px] px-xs rounded-full bg-surface-container-high text-[12px] font-bold">
                      ${(p.direcciones || []).length}</span>
                  </td>
                  <td class="py-sm pr-md text-right whitespace-nowrap">
                    <button data-dir="${escapeHtml(p.id)}" title="Direcciones de fabrica"
                      class="text-secondary hover:text-primary p-xs"><span class="material-symbols-outlined text-[20px]">factory</span></button>
                    <button data-edit="${escapeHtml(p.id)}" title="Editar"
                      class="text-secondary hover:text-primary p-xs"><span class="material-symbols-outlined text-[20px]">edit</span></button>
                    <button data-del="${escapeHtml(p.id)}" title="Eliminar"
                      class="text-secondary hover:text-error p-xs"><span class="material-symbols-outlined text-[20px]">delete</span></button>
                  </td>
                </tr>
                ${selectedProveedorId === p.id ? renderDireccionesPanel(p) : ''}
              `).join('')}
            </tbody>
          </table>
        </div>
      </div>
    `;

    const search = stage.querySelector('#ab-prov-buscar');
    search.addEventListener('input', e => { filtro = e.target.value; draw();
      const s = stage.querySelector('#ab-prov-buscar'); if (s){ s.focus(); s.setSelectionRange(s.value.length, s.value.length);} });
    stage.querySelector('#ab-nuevo-prov').addEventListener('click', () => openProveedorModal(null, draw));
    stage.querySelectorAll('[data-edit]').forEach(b => b.addEventListener('click',
      () => openProveedorModal(proveedores.find(x => x.id === b.dataset.edit), draw)));
    stage.querySelectorAll('[data-del]').forEach(b => b.addEventListener('click',
      () => deleteProveedor(b.dataset.del, draw)));
    stage.querySelectorAll('[data-dir]').forEach(b => b.addEventListener('click', () => {
      selectedProveedorId = selectedProveedorId === b.dataset.dir ? null : b.dataset.dir;
      draw();
    }));

    wireDireccionesPanel(stage, draw);
  }

  draw();
}

function renderDireccionesPanel(p) {
  const dirs = p.direcciones || [];
  return `
    <tr class="bg-surface-container-low"><td colspan="7" class="p-md">
      <div class="border border-outline-variant rounded-lg p-md bg-surface-container-lowest">
        <div class="flex items-center justify-between mb-sm">
          <h4 class="font-bold text-on-surface">
            <span class="material-symbols-outlined text-[18px] align-middle mr-xs">factory</span>
            Direcciones de fabrica — ${escapeHtml(p.nombre || p.id)}
          </h4>
          <button data-adddir="${escapeHtml(p.id)}"
            class="bg-surface-container-high text-on-surface px-sm py-xs rounded-lg text-[13px] font-bold hover:bg-surface-container-highest">
            <span class="material-symbols-outlined text-[16px] align-middle mr-xs">add_location_alt</span>Agregar direccion
          </button>
        </div>
        ${dirs.length === 0 ? `<p class="text-secondary text-[13px] py-sm">Sin direcciones registradas. Agrega la ubicacion de la fabrica o bodega de retiro.</p>` : `
        <table class="w-full text-[13px]">
          <thead><tr class="text-left text-[11px] uppercase tracking-wide text-secondary border-b border-outline-variant">
            <th class="py-xs pr-md">Fabrica / Planta</th><th class="py-xs pr-md">Direccion</th>
            <th class="py-xs pr-md">Comuna</th><th class="py-xs pr-md">Region</th><th class="py-xs text-right">Acciones</th>
          </tr></thead>
          <tbody>
            ${dirs.map(d => `
              <tr class="border-b border-outline-variant/50">
                <td class="py-xs pr-md">${escapeHtml(d.nombre_fabrica || '—')}</td>
                <td class="py-xs pr-md">${escapeHtml(d.direccion || '—')}</td>
                <td class="py-xs pr-md">${escapeHtml(d.comuna || '—')}</td>
                <td class="py-xs pr-md">${escapeHtml(d.region || '—')}</td>
                <td class="py-xs text-right whitespace-nowrap">
                  <button data-editdir="${d.id}" class="text-secondary hover:text-primary p-xs"><span class="material-symbols-outlined text-[18px]">edit</span></button>
                  <button data-deldir="${d.id}" class="text-secondary hover:text-error p-xs"><span class="material-symbols-outlined text-[18px]">delete</span></button>
                </td>
              </tr>`).join('')}
          </tbody>
        </table>`}
      </div>
    </td></tr>
  `;
}

function wireDireccionesPanel(stage, redraw) {
  stage.querySelectorAll('[data-adddir]').forEach(b => b.addEventListener('click',
    () => openDireccionModal(b.dataset.adddir, null, redraw)));
  stage.querySelectorAll('[data-editdir]').forEach(b => b.addEventListener('click', () => {
    const prov = proveedores.find(p => p.id === selectedProveedorId);
    const dir = (prov?.direcciones || []).find(d => String(d.id) === b.dataset.editdir);
    openDireccionModal(selectedProveedorId, dir, redraw);
  }));
  stage.querySelectorAll('[data-deldir]').forEach(b => b.addEventListener('click',
    () => deleteDireccion(b.dataset.deldir, redraw)));
}

function modalShell(titulo, bodyHtml) {
  const wrap = document.createElement('div');
  wrap.className = 'fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-md';
  wrap.innerHTML = `
    <div class="bg-surface-container-lowest rounded-lg shadow-xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
      <div class="flex items-center justify-between px-lg py-md border-b border-outline-variant">
        <h3 class="text-headline-sm font-bold text-on-surface">${escapeHtml(titulo)}</h3>
        <button data-close class="text-secondary hover:text-error"><span class="material-symbols-outlined">close</span></button>
      </div>
      <div class="p-lg">${bodyHtml}</div>
    </div>`;
  document.body.appendChild(wrap);
  const close = () => wrap.remove();
  wrap.querySelector('[data-close]').addEventListener('click', close);
  wrap.addEventListener('click', e => { if (e.target === wrap) close(); });
  return { wrap, close };
}

function field(label, id, value = '', type = 'text', extra = '') {
  return `
    <label class="block mb-sm">
      <span class="text-[12px] uppercase tracking-wide text-secondary font-bold">${label}</span>
      <input id="${id}" type="${type}" value="${escapeHtml(value ?? '')}" ${extra}
        class="mt-xs w-full border border-outline-variant rounded-lg px-md py-sm text-body-md focus:border-primary outline-none" />
    </label>`;
}

function openProveedorModal(prov, redraw) {
  const esNuevo = !prov;
  const { wrap, close } = modalShell(esNuevo ? 'Nuevo Proveedor' : 'Editar Proveedor', `
    ${field('ID Proveedor', 'f-id', prov?.id || '', 'text', esNuevo ? '' : 'disabled')}
    ${field('Nombre Proveedor', 'f-nombre', prov?.nombre || '')}
    ${field('Nombre Contacto', 'f-cnombre', prov?.contacto_nombre || '')}
    ${field('Correo Contacto', 'f-ccorreo', prov?.contacto_correo || '', 'email')}
    ${field('Telefono Contacto', 'f-ctel', prov?.contacto_telefono || '')}
    <label class="flex items-center gap-sm mt-sm mb-md text-body-md">
      <input id="f-activo" type="checkbox" ${prov?.activo === false ? '' : 'checked'} class="w-4 h-4"/>
      <span>Proveedor activo</span>
    </label>
    <div class="flex justify-end gap-sm">
      <button data-cancel class="px-md py-sm rounded-lg text-secondary hover:bg-surface-container-high">Cancelar</button>
      <button data-save class="bg-primary text-on-primary px-md py-sm rounded-lg font-bold hover:opacity-90">Guardar</button>
    </div>
  `);
  wrap.querySelector('[data-cancel]').addEventListener('click', close);
  wrap.querySelector('[data-save]').addEventListener('click', async () => {
    const id = wrap.querySelector('#f-id').value.trim();
    const nombre = wrap.querySelector('#f-nombre').value.trim();
    if (!id)     { showAlert('El ID del proveedor es obligatorio', 'error'); return; }
    if (!nombre) { showAlert('El nombre del proveedor es obligatorio', 'error'); return; }
    const payload = {
      id, nombre,
      contacto_nombre: wrap.querySelector('#f-cnombre').value.trim() || null,
      contacto_correo: wrap.querySelector('#f-ccorreo').value.trim() || null,
      contacto_telefono: wrap.querySelector('#f-ctel').value.trim() || null,
      activo: wrap.querySelector('#f-activo').checked,
      updated_at: new Date().toISOString(),
      updated_by: await getUserEmail(),
    };
    const { error } = await supabase.from('abast_proveedores').upsert(payload);
    if (error) { showAlert('Error al guardar: ' + error.message, 'error'); return; }
    showAlert('Proveedor guardado', 'success');
    close();
    proveedores = await loadProveedores();
    redraw();
  });
}

async function deleteProveedor(id, redraw) {
  if (!confirm('¿Eliminar el proveedor y todas sus direcciones de fabrica?')) return;
  const { error } = await supabase.from('abast_proveedores').delete().eq('id', id);
  if (error) { showAlert('Error al eliminar: ' + error.message, 'error'); return; }
  if (selectedProveedorId === id) selectedProveedorId = null;
  showAlert('Proveedor eliminado', 'success');
  proveedores = await loadProveedores();
  redraw();
}

function openDireccionModal(proveedorId, dir, redraw) {
  const esNueva = !dir;
  const { wrap, close } = modalShell(esNueva ? 'Nueva direccion de fabrica' : 'Editar direccion', `
    ${field('Fabrica / Planta (etiqueta)', 'd-fab', dir?.nombre_fabrica || '')}
    ${field('Direccion', 'd-dir', dir?.direccion || '')}
    ${field('Comuna', 'd-com', dir?.comuna || '')}
    ${field('Region', 'd-reg', dir?.region || '')}
    <div class="flex justify-end gap-sm mt-md">
      <button data-cancel class="px-md py-sm rounded-lg text-secondary hover:bg-surface-container-high">Cancelar</button>
      <button data-save class="bg-primary text-on-primary px-md py-sm rounded-lg font-bold hover:opacity-90">Guardar</button>
    </div>
  `);
  wrap.querySelector('[data-cancel]').addEventListener('click', close);
  wrap.querySelector('[data-save]').addEventListener('click', async () => {
    const payload = {
      proveedor_id: proveedorId,
      nombre_fabrica: wrap.querySelector('#d-fab').value.trim() || null,
      direccion: wrap.querySelector('#d-dir').value.trim() || null,
      comuna: wrap.querySelector('#d-com').value.trim() || null,
      region: wrap.querySelector('#d-reg').value.trim() || null,
      updated_at: new Date().toISOString(),
    };
    let error;
    if (esNueva) {
      ({ error } = await supabase.from('abast_proveedor_direcciones').insert(payload));
    } else {
      ({ error } = await supabase.from('abast_proveedor_direcciones').update(payload).eq('id', dir.id));
    }
    if (error) { showAlert('Error al guardar direccion: ' + error.message, 'error'); return; }
    showAlert('Direccion guardada', 'success');
    close();
    proveedores = await loadProveedores();
    redraw();
  });
}

async function deleteDireccion(id, redraw) {
  if (!confirm('¿Eliminar esta direccion de fabrica?')) return;
  const { error } = await supabase.from('abast_proveedor_direcciones').delete().eq('id', id);
  if (error) { showAlert('Error al eliminar: ' + error.message, 'error'); return; }
  showAlert('Direccion eliminada', 'success');
  proveedores = await loadProveedores();
  redraw();
}

// ============================================================================
// SUBMENU 2: CALENDARIO SUCURSALES  (rediseño moderno)
// ============================================================================
function getCentros() {
  const db = getDatabase();
  return (db.logisticsCentres || []).slice().sort((a, b) =>
    String(a.nombre || a.id).localeCompare(String(b.nombre || b.id)));
}

function getNombreCentro(id) {
  const db = getDatabase();
  const c = (db.logisticsCentres || []).find(x => x.id === id);
  return c ? (c.nombre || id) : id;
}

async function loadCalendario(centro) {
  const { data, error } = await supabase
    .from('abast_calendario').select('*').eq('centro', centro);
  if (error) { console.error(error); showAlert('Error al cargar calendario: ' + error.message, 'error'); return {}; }
  const m = {};
  (data || []).forEach(r => { m[`${r.dia}-${r.bloque}`] = r; });
  return m;
}

async function renderCalendario(stage) {
  if (!CALENDARIOS[calOrigen]) calOrigen = '1003';

  stage.innerHTML = `
    <div class="bg-surface-container-lowest border border-outline-variant shadow-sm rounded-xl overflow-hidden">
      <div class="bg-gradient-to-r from-primary to-primary/80 px-lg py-md flex flex-wrap items-center justify-between gap-md">
        <div class="flex items-center gap-sm">
          <span class="material-symbols-outlined text-white text-[28px]">event_available</span>
          <div>
            <h3 class="text-headline-sm font-bold text-white leading-tight">GESTIÓN TRONCALES – CALENDARIO SUCURSALES</h3>
          </div>
        </div>
        <div class="flex gap-sm">
          ${Object.entries(CALENDARIOS).map(([id, c]) => `
            <button data-origen="${id}" class="px-md py-sm rounded-lg text-[13px] font-bold transition-all
              ${calOrigen === id ? 'bg-white text-primary shadow' : 'bg-white/20 text-white hover:bg-white/30'}">
              <span class="material-symbols-outlined text-[16px] align-middle mr-xs">warehouse</span>${escapeHtml(c.nombre)} (${id})
            </button>`).join('')}
        </div>
      </div>

      <div id="cal-msg"></div>
      <div class="p-lg">
        <div id="cal-grid"></div>
        <div class="flex items-center justify-end gap-md mt-lg">
          <span id="cal-inline-ok" class="hidden items-center gap-xs text-green-700 font-bold text-[13px]">
            <span class="material-symbols-outlined text-[18px]">check_circle</span>Calendario guardado correctamente
          </span>
          <button id="cal-save" class="bg-primary text-white px-lg py-sm rounded-lg font-bold hover:opacity-90 shadow-sm transition-all inline-flex items-center gap-xs">
            <span class="material-symbols-outlined text-[18px]">save</span>Guardar calendario
          </button>
        </div>
      </div>
    </div>
  `;

  stage.querySelectorAll('[data-origen]').forEach(btn => btn.addEventListener('click', async () => {
    calOrigen = btn.dataset.origen;
    await renderCalendario(stage);
  }));

  calMatrix = await loadCalendario(calOrigen);
  drawGrid(stage);

  stage.querySelector('#cal-save').addEventListener('click', () => saveCalendario(stage));
}

function drawGrid(stage) {
  const grid = stage.querySelector('#cal-grid');
  const cfg = CALENDARIOS[calOrigen];
  const dias = cfg.dias;
  const bloquesBase = cfg.bloques;
  const destinos = cfg.destinos;

  const optsHtml = `<option value="">— vacío —</option>` +
    destinos.map(id => `<option value="${id}">${id} ${escapeHtml(getNombreCentro(id))}</option>`).join('');

  grid.innerHTML = `
    <div class="overflow-x-auto rounded-lg border border-outline-variant">
      <table class="w-full text-[13px] border-collapse">
        <thead>
          <tr class="text-left text-[11px] uppercase tracking-wide text-secondary bg-surface-container-high">
            <th class="py-sm px-md border-b border-outline-variant w-[130px]">Bloque Horario</th>
            ${dias.map(d => `<th class="py-sm px-sm border-b border-l border-outline-variant text-center min-w-[150px]">
              <span class="material-symbols-outlined text-[15px] align-middle text-primary mr-xs">today</span>${escapeHtml(d.lbl)}
            </th>`).join('')}
          </tr>
        </thead>
        <tbody>
          ${bloquesBase.map((bloque, bi) => `
            <tr class="${bi % 2 ? 'bg-surface-container-lowest' : 'bg-surface-container-low/40'} hover:bg-primary/5 transition-colors">
              <td class="py-sm px-md font-data-mono font-bold text-primary whitespace-nowrap border-b border-outline-variant/50">
                <span class="material-symbols-outlined text-[15px] align-middle mr-xs">schedule</span>${bloque}</td>
              ${dias.map(d => {
                const dayBloques = d.bloques || bloquesBase;
                if (!dayBloques.includes(bloque)) {
                  return `<td class="py-sm px-sm text-center bg-surface-dim/20 border-b border-l border-outline-variant/40"><span class="text-[11px] text-secondary">—</span></td>`;
                }
                const key = `${d.n}-${bloque}`;
                const cell = calMatrix[key] || {};
                const d1 = cell.centro_destino_1 || '';
                const d2 = cell.centro_destino_2 || '';
                return `<td class="py-sm px-xs text-center border-b border-l border-outline-variant/40">
                  <div class="flex flex-col gap-[4px]">
                    <select data-dest="${key}-1" class="w-full border border-outline-variant rounded-md px-[6px] py-[4px] text-[11px] focus:border-primary focus:ring-1 focus:ring-primary/30 outline-none bg-surface-container-lowest">
                      ${optsHtml.replace(`value="${d1}"`, `value="${d1}" selected`)}
                    </select>
                    <select data-dest="${key}-2" class="w-full border border-outline-variant rounded-md px-[6px] py-[4px] text-[11px] focus:border-primary focus:ring-1 focus:ring-primary/30 outline-none bg-surface-container-lowest">
                      ${optsHtml.replace(`value="${d2}"`, `value="${d2}" selected`)}
                    </select>
                  </div>
                </td>`;
              }).join('')}
            </tr>`).join('')}
        </tbody>
      </table>
    </div>
    <p class="text-[12px] text-secondary mt-sm inline-flex items-center gap-xs">
      <span class="material-symbols-outlined text-[14px]">info</span>
      Seleccione hasta 2 centros destino por bloque horario.
    </p>
  `;
}

async function saveCalendario(stage) {
  const grid = stage.querySelector('#cal-grid');
  const btn = stage.querySelector('#cal-save');
  const email = await getUserEmail();
  const now = new Date().toISOString();
  const cfg = CALENDARIOS[calOrigen];
  const rows = [];

  if (btn) { btn.disabled = true; btn.classList.add('opacity-60'); }

  cfg.dias.forEach(d => {
    const dayBloques = d.bloques || cfg.bloques;
    dayBloques.forEach(bloque => {
      const key = `${d.n}-${bloque}`;
      const sel1 = grid.querySelector(`[data-dest="${key}-1"]`);
      const sel2 = grid.querySelector(`[data-dest="${key}-2"]`);
      const cd1 = sel1?.value || null;
      const cd2 = sel2?.value || null;
      rows.push({
        centro: calOrigen, dia: d.n, bloque,
        habilitado: !!(cd1 || cd2),
        cupos: (cd1 ? 1 : 0) + (cd2 ? 1 : 0),
        sobre_cupo: false,
        centro_destino_1: cd1 || null,
        centro_destino_2: cd2 || null,
        updated_by: email, updated_at: now,
      });
    });
  });

  const { error } = await supabase
    .from('abast_calendario')
    .upsert(rows, { onConflict: 'centro,dia,bloque' });

  if (btn) { btn.disabled = false; btn.classList.remove('opacity-60'); }

  if (error) { showAlert('Error al guardar calendario: ' + error.message, 'error'); return; }

  // Confirmación visible de guardado exitoso (AJUSTE 3.0)
  showAlert('✓ Calendario guardado correctamente', 'success');
  const msg = stage.querySelector('#cal-msg');
  if (msg) {
    msg.innerHTML = `<div class="mx-lg mt-md px-md py-sm rounded-lg bg-green-50 border border-green-300 text-green-800 text-[13px] font-bold inline-flex items-center gap-xs">
      <span class="material-symbols-outlined text-[18px]">check_circle</span>Calendario guardado correctamente</div>`;
    setTimeout(() => { if (msg) msg.innerHTML = ''; }, 4000);
  }
  const inlineOk = stage.querySelector('#cal-inline-ok');
  if (inlineOk) { inlineOk.classList.remove('hidden'); inlineOk.classList.add('inline-flex'); setTimeout(() => { inlineOk.classList.add('hidden'); inlineOk.classList.remove('inline-flex'); }, 4000); }

  calMatrix = await loadCalendario(calOrigen);
}

// build 20260817f
