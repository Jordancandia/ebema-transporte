# Snapshot de PRD — 2026-09-13 (Supabase project: humhokvdowfqicjopbhf)

Este snapshot se generó para responder a tu pedido: "revisa lo que tenemos hoy en PRD, entiéndelo y cuando restaures, para volver a implementar los ajustes que le hemos hecho". Es un respaldo manual de las tablas de configuración/negocio más "vivas" (con ediciones manuales recientes), para que si en algún momento se hace un **Point-in-Time Recovery (PITR)** en Supabase, sepamos exactamente qué reaplicar después del restore.

## Contexto del incidente

- `routes`, `route_tolls`, `transport_zones`, `transports` quedaron en 0 filas (segunda vez que pasa — la primera fue el viernes, con `tarifas`/`motor de costos`/`tarifas clientes` también afectados).
- Causa raíz identificada y corregida en el código (ver `incident_routes_wipe_2026-09-13.md` en tu memoria de proyecto):
  1. `abastecimiento.js` importaba una versión vieja de `data.js` (`?v=20260714a` vs `?v=20260909c` del resto de la app) → instancia de módulo desconectada, sin datos de rutas.
  2. `syncToSupabase()` sincronizaba `routes`/`route_tolls`/`transport_zones` como si estuvieran vacías cuando no se habían cargado en la sesión (`_routesLoaded === false`), y como el sync hace upsert + DELETE de lo que no está en la lista local, una lista local vacía = borrar todo en Supabase.
- Ya apliqué un **guardarraíl a nivel de base de datos** (trigger `fn_prevent_mass_delete()` en las 4 tablas) que bloquea cualquier DELETE masivo (>20 filas Y >30% de la tabla) con una excepción — esto es independiente de que el código JS esté bien o mal, así que aunque vuelva a pasar un bug similar, la base de datos ya no lo va a permitir.
- `routes` ya se recuperó parcialmente (1550 de ~3400 filas) reproduciendo las migraciones `routes_batch_00`..`routes_batch_30` guardadas en `supabase_migrations.schema_migrations`.
- `route_tolls`, `transport_zones`, `transports` siguen en 0 — **no existe una fuente de recuperación tipo migración para estas 3 tablas**, se poblaron por uso de la app, no por seed. La única forma de recuperarlas es un PITR de Supabase.

## Qué contiene este snapshot

Las siguientes tablas fueron identificadas como las que tienen ediciones manuales recientes (no son datos que se regeneren solos vía ingesta diaria), y por lo tanto **son las que un PITR a un punto anterior podría hacer retroceder**, perdiendo cambios legítimos hechos después de ese punto:

| Archivo | Última edición | Riesgo si el PITR va más atrás de esa fecha |
|---|---|---|
| `tariff_config.json` | 2026-06-13 | Bajo (no se ha tocado desde junio) — nota: el campo `participacionRutas` es un mapa gigante, se omitió el contenido pero se dejó la instrucción de cómo volver a extraerlo si hace falta |
| `client_tariff_config.json` | 2026-06-13 | Bajo — mismo caso, campo `comunaCluster` omitido por tamaño |
| `cluster_rutas.json` | 2026-07-13 | Medio — 14 filas, Puerto Montt |
| `abast_calendario.json` | 2026-08-14 | Medio-Alto — calendario de retiros CD 1003/1081, editado por ti el 11 y 14 de agosto |
| `abast_retiro_estado.json` | 2026-09-11 (¡el más reciente!) | **Alto** — esta es la tabla más "viva", con ediciones tuyas y de nramirez/racevedo hasta ayer |
| `extra_costs.json` | 2026-07-09 | Medio — costos de barcaza Puerto Montt |
| `truck_types.json` | (sin timestamp) | Bajo-Medio — tarifas de camión por centro |
| `app_users.json` | — | Bajo (usuarios y accesos, se puede reconstruir) |
| `logistics_centres.json` | — | Bajo (maestro de centros, estable) |
| `quotes_history.json` | — | Muy bajo (solo 2 filas, datos de prueba) |
| `historico_global_raw.txt` | — | Bajo — 1 fila, JSON gigante (557 KB), respaldado tal cual (texto crudo, no reformateado) |

**La tabla más importante a vigilar es `abast_retiro_estado`**: tiene ediciones hasta el 11 de septiembre (2 días antes del incidente), hecha por 3 personas distintas (tú, nramirez, racevedo). Si el punto de restauración del PITR queda antes de esa fecha, hay que reaplicar esos cambios manualmente desde este JSON después del restore.

Confirmé también el resto de las tablas del proyecto (`list_tables`): las demás en 0 filas (`providers`, `transports_camiones`, `transports_choferes`, `abast_proveedores`, `abast_proveedor_direcciones`, `mfa_challenges`) están vacías porque nunca se han usado, no por el incidente — no son parte del respaldo. Las tablas de indicadores (`trc_live`, `trc_hist`, `trc_log`, `ind_otif`, `ind_flete_pagado`, `ind_flete_cobrado`, `ind_flete_tercero`, `ind_log`) se recargan solas todos los días a las 08:00 desde Drive/Gmail, así que un PITR no las pone en riesgo real (se vuelven a pisar al otro día).

## Sobre ejecutar el PITR: no puedo hacerlo yo directamente

Revisé la herramienta de restauración que tengo disponible (`restore_project`) y **solo sirve para reactivar un proyecto pausado/inactivo** (la usé para probar el proyecto de QA) — no acepta una fecha/hora, así que no puede hacer un Point-in-Time Recovery a un instante específico. Esa función solo está en el Dashboard de Supabase (Database → Backups → Point in Time Recovery) o vía la API de gestión con el add-on de PITR habilitado, a los que no tengo acceso desde aquí. Tampoco intenté un atajo por API cruda: es una restauración irreversible de toda la base de producción, y elegir mal el punto puede perder trabajo tuyo o de tu equipo — es una decisión que te corresponde confirmar a ti, con el punto exacto.

### Punto de restauración recomendado (para minimizar pérdidas)

No encontré en los logs de Postgres/PostgREST el momento exacto del borrado de hoy (la ventana de logs de 24h no lo capturó — probablemente el borrado ocurrió antes de esa ventana o no quedó registrado como sentencia individual). Con la evidencia que sí tengo (última edición conocida en cualquier tabla: `abast_retiro_estado` el 2026-09-11 14:21 UTC; nada editado conocido el 12 de septiembre), la recomendación más segura es:

**Restaurar al 2026-09-12 23:59 UTC (justo antes de que empezara el día de hoy, 13-09-2026).**

Con ese punto: se conservan todas las ediciones conocidas hasta el 11 de septiembre, se recuperan `route_tolls`/`transport_zones`/`transports` completos y las ~1850 filas de `routes` que faltan, y solo se pierde lo que haya pasado específicamente el 12 de septiembre (no detecté ninguna edición ese día en las tablas revisadas, pero no puedo garantizar que no haya habido ninguna en otras tablas del sistema). Si recuerdas algo puntual que se hizo el 12 de septiembre, dímelo y ajusto la recomendación.

### Pasos para que tú lo ejecutes en el Dashboard

1. Entra a https://supabase.com/dashboard/project/humhokvdowfqicjopbhf/database/backups/pitr
2. Elige el punto de restauración: 2026-09-12 23:59 UTC (o el que prefieras según lo de arriba).
3. Confirma la restauración (Supabase te va a pedir doble confirmación por ser producción).
4. Avísame cuando termine — comparo el estado resultante contra este snapshot y te digo exactamente qué reaplicar (probablemente solo `abast_retiro_estado` si hubo cambios el 12, y reviso si `routes` quedó con más filas de las que recuperé manualmente).
