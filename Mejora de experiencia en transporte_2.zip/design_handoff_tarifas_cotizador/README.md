# Handoff: Tarifas (Transporte + Clientes) y Cotizador de Despacho

## Resumen
Rediseño de dos módulos de SIT EBEMA (repo `Jordancandia/ebema-transporte`, rama `main`):
- **Tarifas**: 8 vistas de Transporte y 7 de Clientes, reunidas bajo un solo menú «Tarifas».
- **Cotizador de Despacho**.

El estilo es el mismo de la Propuesta A de Gestión Troncales (ver `design_handoff_gestion_troncales/README.md`): mismo shell, tarjetas de indicadores que filtran, chips, tablas y píldoras.

## Sobre los archivos
Los `.dc.html` son **referencias de diseño en HTML**, no código de producción. Los datos son de ejemplo (rutas, precios e histórico inventados). Las **fórmulas** sí replican el código actual:
- `tarifas-engine.js` (`calcularCostoRuta`)
- `zcap.js` (ZCAP por tarifa km)
- `cotizador-engine.js` y `tarifas-clientes.js` (ZFMP, ZFMI, Express)

La tarea es **recrearlos dentro de la app actual**: JS vanilla con módulos ES, Tailwind, Supabase y Material Symbols. Hay que mantener las consultas y la persistencia existentes.

Para ver los prototipos, abre los `.dc.html` en el navegador; requieren `support.js` en la misma carpeta. `Tarifas.dc.html` acepta la propiedad `vistaInicial` para elegir con qué vista abre.

## Fidelidad
**Alta fidelidad.** Los colores, la tipografía, los espaciados y las interacciones son los finales.

---

## Tokens (iguales a Gestión Troncales)
**Colores**
- Primario `#b5000b` (hover `#930007`).
- Selección `#ffdad5` / `#fff5f3`.
- Tinta `#191c1d`; secundario `#5c5f61`; atenuado `#444749`.
- Fondo `#f8f9fa`; superficies `#f3f4f5`, `#edeeef`, `#e7e8e9`.
- Bordes `#e1e3e4` / `#edeeef`.
- **Editado sin guardar**: borde `#ca8a04`, fondo `#fffbeb`.
- **Manual / override**: `#7e22ce`, con fondo de fila `#faf5ff`.

**Tipografía**
- Hanken Grotesk 400–900; JetBrains Mono 500 para códigos.
- Escala: 28/36 (tarjeta), 24/32 (h1), 16, 14, 13, 12 y 11 (etiquetas en mayúsculas con tracking 0.05em).

**Forma**
- Radios: 2, 4, 8 y 12 (píldoras).

**Números**
- Todos los números llevan **separador de miles** es-CL (`toLocaleString('es-CL')`).
- Los $/kg van con 2 decimales (`$2,72/kg`).
- Los inputs editables son `type=text inputmode=decimal`, formateados con miles. Mientras el campo tiene foco se muestra lo que el usuario escribe tal cual (sin reformatear); al salir se vuelve a formatear.

**Píldoras**
- `ok` `#dcfce7/#14532d`
- `warn` `#fef3c7/#713f12`
- `bad` `#ffdad6/#93000a`
- `orange` `#ffedd5/#7c2d12`
- `info` `#dbeafe/#1e3a8a`
- `purple` `#f3e8ff/#581c87`
- `mute` `#edeeef/#444749`

---

## TARIFAS — estructura común

**Menú lateral**
- Un solo grupo «Tarifas» con dos secciones, Transporte y Clientes (ya existe en `app.js` con `sections`).
- Ancho 288px; los textos largos terminan en elipsis.

**Cadena de cálculo**
- Franja bajo el título con 3 etapas.
  - Transporte: Insumos → Cálculo → Tarifas transportista.
  - Clientes: Análisis → Tarifa por kilo → Tarifa por pedido.
- Los chips de cada etapa navegan a su vista; la vista activa va en rojo.

**Edición con barra de cambios**
- Todos los parámetros se editan en línea y **recalculan en vivo**.
- Una barra amarilla bajo el header muestra «N cambio(s) sin guardar», el impacto («Cambian X de Y ZCAP; el promedio sube/baja Z%») y los botones **Descartar** y **Guardar y recalcular**.
- Implementación sugerida: mantener un borrador del `cfg` en memoria, calcular el diff contra el guardado y hacer upsert a Supabase al guardar.

**Filtros**
- Barra de chips «Centro origen».
- Segmentado de tipo de ruta y/o de camión, según la vista.
- Selector de destino (en el Motor) y buscador.
- Las tarjetas de indicadores filtran al hacer clic.

**Botón «Refrescar tarifas»** (en Tarifas por Camión, $/Kg y Min/Max)
- En $/Kg y Min/Max las tablas usan una **foto** del ZCAP vigente.
- Si Tarifas Rutas cambió, el botón es rojo y dice «Refrescar tarifas · N desactualizadas». Al presionarlo se recalcula.
- Sin cambios pendientes, el botón queda gris con el texto «Tarifas al día».

## Tarifas Transporte

### Peajes — «Valor peajes por ruta y ejes»
- Tres pestañas: **Peajes regionales**, **Peajes interregionales** y **Administrador de concesiones** (`PEAJES_SUBS`).
- Tabla de regionales/interregionales:
  - Columnas: Ruta · Origen · Destino · Ejes · Peaje ida · Peaje vuelta · KM · Estado · Editar.
  - **Estado** tiene solo dos valores: «Peaje calculado» (`info`) o «Sin peaje» (`mute`). Se eliminan las etiquetas Automático y Manual.
  - **Lápiz por fila**: abre los inputs de ida/vuelta con la fila en amarillo. Si el valor queda distinto al calculado, se muestra en morado con la nota «manual».
  - Tarjetas: Tramos / Peaje calculado / Sin peaje.
- Administrador de concesiones:
  - Columnas: Concesionaria · Ruta · Tramo · Región · Tipo · Rutas c/peaje · Variación anual % (editable).
  - **Agregar concesión** crea una fila amarilla con inputs de texto y un botón para quitarla.

### Combustibles y Rendimientos — «Precio de combustibles y rendimientos por camión»
- Tabla por centro: Centro · Precio c/IVA (editable) · IVA · Precio neto · Actualizado · Estado (Vigente/Revisar). **Sin la columna Fuente.**
- Tabla de rendimiento por camión: Cargado (ida) y Vacío (vuelta) en km/l, ambos editables, más Ejes.

### Seguros y Permisos
- Seguro de carga en UF/mes por centro, con su equivalente en CLP.
- SOAP y permiso anual por camión.

### Costos Extras — «Costos adicionales asociados a las rutas. Ej: barcaza, viático»
- Filtro por centro origen y buscador.
- Columnas: Zona · Comuna destino · Centro origen · Tipo camión · Ítem · Costo ida · Costo vuelta · Total · Activo (toggle) · Borrar.
- **Agregar costo** abre un modal:
  - Comuna destino\* (select de rutas del centro filtrado)
  - Ítem\*: Barcaza / Viático / Hospedaje
  - Tipo de camión\*
  - Costo ida / Costo vuelta, con al menos uno obligatorio
- El costo se aplica **por tipo de camión**. Hoy se aplica por ejes (`extra_costs.ejes`); el cambio sugerido es agregar la columna `truck_type` y conservar los ejes como respaldo.

### Variables Generales — «Parámetros de cálculo de costo»
- Tarjetas de parámetros:
  - Económicas: UF y margen.
  - Chofer: días hábiles y comisión.
  - Ciclos: mantención, neumáticos y GPS.
  - Factor de ruta.
- Tablas: por camión (mantención, neumáticos y KM ofrecidos) y sueldo mínimo por centro.

### Motor de Costos — «Cálculo de costos de transporte por ruta»
- **Tabla igual a PRD** (`HEADERS_BASE` en `renderResultados`):
  - Centro · ID ruta · Destino · Clasificación · Tipo camión (kg) · KM · Peajes · Comb. ida · Comb. vuelta · Seguros · Costos extras · Mantención · Neumáticos · GPS · Rem. chofer · Var. chofer · Factor · Costo vuelta · Costo total · Costo/KM.
  - Solo en regionales se suman Peso y T. ponderada.
  - Paginación de 25 filas; encabezado sticky.
- **Filtros**: Regionales / Interregionales / Troncales / Todas; centro origen; tipo de camión; destino (select); buscador.
- **Clic en una fila** la marca con franja roja y muestra debajo el **desglose de 12 pasos**:
  - Cada ítem trae su fórmula con valores reales y un enlace a la vista que lo define.
  - Tres tarjetas: Costo ruta total, Costo por km y ZCAP.
- ⚠️ **T. ponderada** = costo total × peso % de la ruta en su centro. **Confirmar la fórmula con producción.**

### Tarifas por Camión — «Tarifas km por centro»
- **Una tabla por centro, con una fila por tipo de camión.** Columnas como en PRD:
  - a. KM base · b. Costo base · c. T. base KM
  - d. Normal pond. · e. Esp. pond. (solo si el centro tiene rutas Montaña/Insular)
  - f. Ajust. normal · g. Ajust. especial
  - Son editables a, b, c, f y g; d y e son calculados.
- **Ponderados**: promedio del costo/km del motor ponderado por las toneladas de cada ruta, separado en rutas normales y especiales.
- **Refrescar tarifas**: recalcula b, f y g ajustándolos al motor. Es un ajuste por mínimos cuadrados sobre `base + (km − kmBase) × tarifa`; si el costo base da negativo queda en 0 y se ajusta la tarifa.

### Tarifas Rutas (ZCAP)
- **ZCAP calculado** = b + c + máx(0, KM − a) × tarifa ajustada (normal o especial). Es la fórmula de `zcap.js`.
- Filtros: **Todas / Regionales / Interregionales / Troncales**, centro y camión.
- Columnas: Centro · Cód. ruta · Destino · Clasificación · Tipo · KM · Tipo camión · ZCAP calculado · **ZCAP manual** (input) · ZCAP vigente · Δ pendiente.
- **ZCAP manual** > 0 reemplaza al calculado: la fila se marca en morado y el vigente dice «manual». Con 0 se vuelve al calculado.
  - Persistencia sugerida: tabla `zcap_manual (route_id, truck_type, valor, updated_by, updated_at)`.
- El **ZCAP vigente** alimenta $/Kg, Min/Max y el Cotizador.

## Tarifas Clientes

### Histórico (6M)
- Tabla por centro de expedición: documentos, entregas, toneladas, gasto, $/kg real, transportistas, rutas y una barra apilada de «Docs por camión».

### Consolidación
- **Una tabla por centro** y filtro por centro.
- Columnas: Despachos · Consolidación real · Real vs. objetivo (barra con marca del objetivo) · **Objetivo** (editable, por centro × camión) · Ton total · Participación ton.

### Densidad Logística y Cluster
- Densidad: Cód. ruta · Destino · Zona · Clientes · Obras · Toneladas · Peso % · Densidad (barra).
- Cluster: las tarjetas A, B y C **responden al filtro de centro**. La tabla muestra densidad, cluster, eje vial, cluster operativo, frecuencia y flota sugerida.

### Frecuencia y Especiales
- Tabla de frecuencias:
  - Columnas: Nombre · Color · Ped. prom. (editable) · Frecuencia · Rutas · Tipo 0000 (toggle) · Eliminar.
  - **Agregar cluster**: fila nueva con nombre y frecuencia editables.
  - **Eliminar cluster**: se deja al menos uno.
- Cuadro **Recargo por exclusividad**: Centro · Recargo %, sin columna de ejemplo.

### Tarifas $/Kg (ZFMP)
- Filtros: Todas / Regionales / Interregionales, centro y camión. Tiene botón Refrescar tarifas.
- Columnas: Centro origen · ID ruta · Destino · Clasificación · **Distancia KM** · Cluster · Tipo camión · ZCAP · Factor consol. · Kilos a consolidar · ZFMP $/kg · **$/kg centro**. **Sin Recargo ni Tarifa Express.**
- **ZFMP** = ZCAP ÷ (capacidad × factor de consolidación del centro).
- ⚠️ **$/kg centro** = Σ (ZFMP de cada camión × su participación en toneladas del centro). **Confirmar con `tarifaCentroPorRuta`** en `tarifas-clientes.js`.

### Tarifa Min/Max (ZFMI)
- Columnas como en el CSV de PRD:
  - Centro origen · ID ruta · Destino · Tipo · Clasificación · Dist. KM · Cluster
  - Tipo camión · Camión mínimo · ZCAP · ZFMI mín. · ZFMX máx. · Express
  - Factor consol. · Kilos a consolidar · Kilos tarif. mín.
- Fórmulas:
  - **ZFMI** = $/kg del camión mínimo × (kilos a consolidar del camión mínimo ÷ pedidos promedio del cluster).
  - **ZFMX** = ZCAP.
  - **Express** = ZCAP × (1 + recargo del centro).
- Filtros: Todas / Regionales / Interregionales, centro y camión. Tiene botón Refrescar tarifas.

---

## COTIZADOR DE DESPACHO (`Cotizador Despacho.dc.html`, reemplaza `renderRatesView`)
- **Descripción**: «Cotizador de despacho a clientes».
- **Layout**: formulario a la izquierda y resultado fijo (sticky) a la derecha. Si no caben dos columnas, el resultado baja debajo del formulario (flex-wrap).
- **Paso 1 · ¿Cómo se mueve la carga?**: tarjetas Desde (Stock en centro / Fábrica entrega en centro / EBEMA retira en fábrica) y Hasta (EBEMA despacha a comuna / Cliente retira en centro).
  - «Cliente retira en centro» solo se habilita con «EBEMA retira en fábrica».
  - Una etiqueta muestra el código del flujo (`FLUJOS`: EBE-DESP, FAB-DESP/EBE-DESP, EBE-RET/CLI-RET, EBE-RET/EBE-DESP).
- **Paso 2 · Origen, destino y kilos**
  - Los campos cambian según el flujo: centro o comuna.
  - Bajo cada comuna se muestra el centro que la atiende y a cuántos km está.
  - Kilos: atajos de 1.000, 5.000, 12.000 y 28.000 kg y una escala con el camión asignado y su % de ocupación.
- **Paso 3 · Tipo de servicio**: se calculan **Consolidado y Exclusivo** a la vez, con la etiqueta «Menor costo» y el $/kg de cada uno.
- **Resultado**:
  - Total grande con $/kg y kilos.
  - Recorrido paso a paso: nodos y tramos coloreados (retiro `#d97706`, troncal `#b5000b`, última milla `#15803d`, directo `#7e22ce`), con monto y regla por tramo.
  - Alertas: ahorro del otro servicio, >28 t y otras.
  - Mientras falten datos, lista lo que falta.
- **Acciones**:
  - **Guardar cotización** explícito: reemplaza el guardado automático a cada tecla.
  - **Copiar** un resumen de texto para el cliente.
  - PDF (sin conectar en el prototipo).
  - Historial «Mis cotizaciones recientes» con botón **Reusar**, que carga la cotización en el formulario.
- **Tarifas retiro troncal (Regla B)**: panel lateral visible **solo para OWNER**, editable por centro.
- ⚠️ Los montos del prototipo vienen de un cálculo simplificado. **En PRD se usa `cotizador-engine.js` tal cual**, alimentado por el ZCAP vigente de Tarifas Rutas.
- El mapa (Leaflet + OSRM) se mantiene como en la app actual.

---

## Cambios de datos sugeridos (Supabase)
1. `zcap_manual (route_id, truck_type, valor, updated_by, updated_at)`: override de ZCAP.
2. `extra_costs.truck_type`: costo extra por tipo de camión. Mantener `ejes` como respaldo.
3. `peaje_manual` o un flag `manual` en `route_tolls`: peajes editados a mano.
4. Concesiones: permitir insert desde la UI en la tabla de concesionarias existente.
5. `consolidacion_objetivo (centro_id, truck_type, pct)`: objetivo por centro × camión.
6. Clusters de frecuencia: permitir insert y delete en la tabla de clusters de `tarifas-clientes`, y reasignar las rutas del cluster eliminado.

## Archivos
- `Tarifas.dc.html`: las 15 vistas, navegables desde el menú.
- `Cotizador Despacho.dc.html`: el cotizador completo.
- `support.js`: runtime necesario para abrir los `.dc.html`.

## Cómo pedírselo a Claude Code
Desde la raíz del repo `ebema-transporte`:
> «Lee `design_handoff_tarifas_cotizador/README.md` y abre los `.dc.html` como referencia visual. Implementa el rediseño en `js/tarifas-transporte.js`, `js/tarifas-clientes.js`, `js/zcap.js` y `js/rates.js`, vista por vista, manteniendo `tarifas-engine.js`, `cotizador-engine.js` y las consultas a Supabase. Empieza por los componentes comunes (barra de cambios, filtros, inputs con miles), luego Tarifas Rutas con ZCAP manual, después el resto de Transporte, Clientes y al final el Cotizador.»

Trabajar en la rama `feature/rediseno-tarifas-cotizador`, validar en QA y después publicar en PRD.
